// Run with: node tests/engine.test.js
const assert = require("assert");
const E = require("../src/engine.js");
const strip = (h) => h.replace(/<[^>]+>/g, "");
let n = 0;
const t = (name, fn) => { fn(); n++; console.log("ok -", name); };

t("parses and finds three terms", () => {
  const p = E.parse("3x² + 2x − 5");
  assert.strictEqual(E.topTerms(p.ast).length, 3);
});
t("roles: coefficient, variable, exponent, constant", () => {
  const p = E.parse("3x^2 - 5");
  assert.deepStrictEqual(p.toks.map((k) => k.role), ["coef", "var", "exp", "exp", "op", "const"]);
});
t("minus-sign meanings", () => {
  const p = E.parse("-3^2 - x");
  assert.deepStrictEqual(p.toks.filter((k) => k.meaning && k.t === "-").map((k) => k.meaning), ["opposite", "subtract"]);
});
t("simplifies with the distributive property", () => {
  assert.strictEqual(E.polyText(E.polyOf(E.parse("-3x(4x^2 - 5)").ast), false), "−12x³ + 15x");
});
t("equivalence", () => {
  assert.ok(E.equivalent(E.parse("3(x+4)").ast, E.parse("3x+12").ast));
  assert.ok(!E.equivalent(E.parse("2(x-3)").ast, E.parse("2x-3").ast));
});
t("readings", () => {
  const p = E.parse("3(x + 2)");
  assert.strictEqual(E.readLiteral(p.ast), "3 times the quantity x plus 2");
  assert.strictEqual(E.meaningPlain(E.readMeaning(p.ast)), "the product of 3 and the sum of x and 2");
});
t("ambiguity alert", () => {
  const a = E.ambiguityCheck(E.parse("2(x - 3) + 3x"));
  assert.strictEqual(E.plainText(a.ast), "2x − 3 + 3x");
});
t("substitution steps end at the right value", () => {
  const steps = E.substitutionSteps(E.parse("3x^2 + 2x - 5").ast, { x: new E.Fr(2) });
  assert.strictEqual(strip(steps[steps.length - 1]), "11");
});
t("friendly parse errors", () => {
  assert.throws(() => E.parse("(x + 2"), /never closed/);
  assert.throws(() => E.parse("3x = 5"), /equation/);
});
console.log(`\n${n} tests passed`);
