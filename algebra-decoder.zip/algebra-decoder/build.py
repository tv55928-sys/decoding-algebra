"""Build index.html from the files in src/.

Usage: python3 build.py
Combines the page shell, styles, engine, UI and teacher layer into one
self-contained index.html (fonts load from Google Fonts).
"""
from pathlib import Path

ROOT = Path(__file__).parent
SRC = ROOT / "src"


def read(name: str) -> str:
    return (SRC / name).read_text(encoding="utf-8")


def main() -> None:
    ui = read("ui.js")
    marker = "/* ============================================================\n   Routing"
    if marker not in ui:
        raise SystemExit("Routing marker not found in src/ui.js")
    i = ui.index(marker)
    ui = ui[:i] + read("teacher.js") + "\n" + ui[i:]

    page = (
        read("shell.html")
        .replace("/*CSS*/", read("style.css"))
        .replace("/*ENGINE*/", read("engine.js"))
        .replace("/*UI*/", ui)
        .replace("<!--PRACTICE-->", read("practice-section.html").rstrip("\n"))
    )
    (ROOT / "index.html").write_text(page, encoding="utf-8")
    print(f"Wrote index.html ({len(page):,} characters)")


if __name__ == "__main__":
    main()
