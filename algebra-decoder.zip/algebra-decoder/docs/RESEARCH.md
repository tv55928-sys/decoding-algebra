# Research behind Algebra Decoder

Fifteen sources informed the app's design. The app's **Research** tab gives the same information, plus a "For your teaching" note for each source.

**Access when reviewed:** full text for Shanahan & Shanahan, Moschkovich, Riccomini et al., MacGregor & Stacey, Arcavi, Hoch & Dreyfus, Landy & Goldstone, and Kirshner & Awtry. Abstracts and published summaries only for Schleppegrell, Rubenstein & Thompson, MacGregor & Price, Duval, Witzel et al., Booth et al., and the IES guide (guide summary and companion materials). Check those against the full articles before citing the app's claims about them.

## 1. Mathematics and language/literacy
| Source | Key finding | Where it shows up |
|---|---|---|
| Schleppegrell, M. J. (2007). The linguistic challenges of mathematics teaching and learning: A research review. *Reading & Writing Quarterly, 23*(2), 139–159. | The math register mixes symbols, speech, writing and graphs, and uses technical words, dense noun phrases and precise linking words. Teachers move students from everyday talk to this register. | Three readings in Say (everyday, symbol by symbol, math meaning); precise teacher talk in Language. |
| Shanahan, T., & Shanahan, C. (2008). Teaching disciplinary literacy to adolescents: Rethinking content-area literacy. *Harvard Educational Review, 78*(1), 40–59. | Mathematicians reread, read for precision down to small words, read to check for errors, and learn math meanings separately from everyday ones. | "Model reading like a mathematician" in Teach the routine; everyday vs. math meanings on word cards; Find the error. |
| Moschkovich, J. N. (2015). Academic literacy in mathematics for English Learners. *Journal of Mathematical Behavior, 40*, 43–62. | Proficiency, practices and discourse are taught together. Vocabulary-only approaches cut language off from reasoning. Everyday and home languages, gestures and representations are resources. | Everyday readings accepted as a start; Talk prompts; Respond scenario on revoicing an English language learner. |
| Riccomini, P. J., Smith, G. W., Hughes, E. M., & Fries, K. M. (2015). The language of mathematics: The importance of teaching and learning mathematical vocabulary. *Reading & Writing Quarterly, 31*(3), 235–252. | Lists ways math vocabulary causes difficulty (e.g., math meanings more precise than everyday ones). Recommends explicit teaching, many exposures, restating in your own words, and game-like practice. | Word cards; vocabulary teaching moves; Word check activity. |

## 2. Decoding symbols and algebraic notation
| Source | Key finding | Where it shows up |
|---|---|---|
| Rubenstein, R. N., & Thompson, D. R. (2001). Learning mathematical symbolism: Challenges and instructional strategies. *Mathematics Teacher, 94*(4), 265–271. | Saying a symbol is surface structure; understanding it is deep structure. Symbols can be said several ways (e.g., students get −3 for −x when x = −3). | The − sign labelled subtract, negative or opposite; several readings per expression; Find the error item on −x². |
| MacGregor, M., & Price, E. (1999). An exploration of aspects of language proficiency and algebra learning. *Journal for Research in Mathematics Education, 30*(4). | Among more than 1,500 students aged 11–15, very few with low awareness of symbols, syntax and ambiguity reached high algebra scores. | Ambiguity alert in Say; "less than" and unspoken-bracket entries in Respond. |
| MacGregor, M., & Stacey, K. (1997). Students' understanding of algebraic notation: 11–15. *Educational Studies in Mathematics, 33*, 1–19. | About 2,000 students in Years 7–10. Errors include reading letters as alphabet positions and writing x³ for 3x (5% in Year 7 to 18% in Year 10). At one school, explicit lessons on brackets and ambiguity raised success from 31% to 81%. | Find the error items on letters and x³ vs 3x; Respond entries; bracket teaching in the routine. |

## 3. Seeing structure
| Source | Key finding | Where it shows up |
|---|---|---|
| Arcavi, A. (1994). Symbol sense: Informal sense-making in formal mathematics. *For the Learning of Mathematics, 14*(3), 24–35. | Eight symbol-sense behaviours, including reading meaning through symbols, checking by substitution, and finding new meaning in equivalent forms. | Predict-first step in Substitute; Simplified view. |
| Hoch, M., & Dreyfus, T. (2004). Structure sense in high school algebra: The effect of brackets. *Proceedings of PME 28*, Vol. 3, 49–56. | Structure sense rose with brackets (6.3%, 13.6%, 17.7%) but stayed rare. The authors suggest teaching students to look before they do. | Squint view and "look before you do" in Scan; lesson 1 of the routine. |
| Landy, D., & Goldstone, R. L. (2007). How abstract is symbolic thought? *Journal of Experimental Psychology: Learning, Memory, and Cognition, 33*(4), 720–733. | Grouping cues that match the order of operations raise accuracy; mismatched spacing cut accuracy by about 39 percentage points on items where order mattered. | Structural spacing in every expression; spacing item in Find the error. |
| Kirshner, D., & Awtry, T. (2004). Visual salience of algebraic transformations. *Journal for Research in Mathematics Education, 35*(4), 224–257. | Students recognized visually neat rules far more readily (73% vs 40%) and found false look-alikes like (x + y)² = x² + y² harder to reject. The authors propose describing structure in words. | Principal operation named in Scan; rules stated in words in Find the error. |

## 4. Representations and instruction
| Source | Key finding | Where it shows up |
|---|---|---|
| Duval, R. (2006). A cognitive analysis of problems of comprehension in a learning of mathematics. *Educational Studies in Mathematics, 61*, 103–131. | Treatments (changes within one system) vs. conversions (changes between systems). Conversion is the deciding factor for learning, and each direction is its own task. | Show panel; Match the tiles (tiles → symbols) and Build it (symbols → tiles). |
| Witzel, B. S., Mercer, C. D., & Miller, M. D. (2003). Teaching algebra to students with learning difficulties: An investigation of an explicit instruction model. *Learning Disabilities Research & Practice, 18*(2), 121–131. | 34 matched pairs in Grades 6–7; students taught with concrete–representational–abstract (CRA) instruction made fewer procedural errors. | Build it; build → draw → write; teacher note to start with physical tiles. |
| Star, J. R., et al. (2015). *Teaching strategies for improving algebra knowledge in middle and high school students* (NCEE 2015-4010). Institute of Education Sciences. | Recommendations: solved problems, including labelled incorrect ones (minimal evidence); structure via precise language and reflective questions (minimal); choosing among strategies (moderate). | Ask yourself questions; precise teacher talk; Find the error; Same or different? strategies. |
| Booth, J. L., Lange, K. E., Koedinger, K. R., & Newton, K. J. (2013). Using example problems to improve student learning in algebra: Differentiating between correct and incorrect examples. *Learning and Instruction, 25*, 24–34. | Incorrect worked examples with explanation prompts appeared especially helpful for conceptual understanding. | Find the error; Respond scenario on comparing incorrect and correct work. |

## Also worth a look
- Ontario Ministry of Education. *Paying Attention to Algebraic Reasoning, K–12* (support document).
- EQAO (2023). *Areas of Strengths and Growth Opportunities, Grade 9 Assessment of Mathematics* — source of the distributive-property example (−3x(4x² − 5)).
