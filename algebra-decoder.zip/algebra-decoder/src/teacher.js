/* ============================================================
   Teacher layer: features of an expression → teaching moves
   ============================================================ */
const REF_TEACH = {
  schleppegrell: "Model the move from everyday talk to math talk out loud, and revoice students' informal language in the math register.",
  shanahan: "Show students how you reread and check. Teach the math meanings of words apart from their everyday meanings.",
  moschkovich: "Keep reasoning and talk together. Let students explain in any language or representation, then refine the language with them.",
  riccomini: "Teach key words explicitly, revisit them often in short bursts, and have students restate them in their own words.",
  rubenstein: "Name each symbol's job aloud, especially the − sign, and accept more than one correct way of saying an expression.",
  macgregorPrice: "Treat ambiguity and word order as things to teach, not only things to correct.",
  macgregorStacey: "Find out what students think letters mean. Introduce letters as numbers and teach brackets explicitly.",
  arcavi: "Ask for predictions and sense checks before and after calculating.",
  hoch: "Have students look at and name the structure before they manipulate anything.",
  landy: "Write with structural spacing on the board and in handouts: tight for multiplication, wide for + and −.",
  kirshner: "State rules in words about structure, and show students tempting false look-alikes.",
  duval: "Plan conversions in both directions. Going one way doesn't mean students can go back.",
  witzel: "Sequence concrete, then drawn, then symbolic, with explicit modelling at each stage.",
  star: "Use labelled incorrect examples, precise language and reflective questions, and let students choose among strategies.",
  booth: "Have students find and explain errors alongside correct examples.",
};
const MODE_NAMES = { say: "Say it right", write: "Write it", spot: "Spot the part", error: "Find the error", same: "Same or different?", tiles: "Match the tiles", build: "Build it", words: "Word check" };
function modeBtn(k) { return `<button type="button" class="chiplink" data-open-mode="${k}">${MODE_NAMES[k]}</button>`; }
document.addEventListener("click", (e) => {
  const b = e.target.closest("[data-open-mode]"); if (!b) return;
  go("practice"); const m = document.querySelector(`#modes [data-mode="${b.dataset.openMode}"]`); if (m) m.click();
  window.scrollTo({ top: 0 });
});
document.addEventListener("click", (e) => {
  const b = e.target.closest("[data-misc]"); if (!b) return;
  e.preventDefault(); go("respond");
  const card = document.getElementById("m-" + b.dataset.misc);
  if (card) { card.scrollIntoView({ block: "center" }); card.classList.add("flash"); setTimeout(() => card.classList.remove("flash"), 1600); }
});
function miscLink(id) { const m = MISC.find((x) => x.id === id); return m ? `<a href="#respond" class="misclink" data-misc="${id}">${m.title}</a>` : ""; }

function features(p) {
  const ts = E.analyzeTerms(p);
  const f = { nTerms: ts.length, like: ts.some((t) => t.likeGroup), vars: [...E.varsIn(p.ast)].sort(), ts };
  (function walk(n) {
    if (n.paren && n.type === "bin") f.brackets = true;
    if (n.type === "bin" && n.op === "^") { f.exponent = true; if (n.left.paren && n.left.type === "bin") f.powerOfGroup = true; }
    const isSum = (k) => k.paren && k.type === "bin" && (k.op === "+" || k.op === "-");
    if (n.type === "bin" && n.op === "*" && (isSum(n.left) || isSum(n.right))) f.distrib = true;
    if (n.type === "neg" && n.arg.type !== "num") f.opposite = true;
    if (n.type === "bin" && n.op === "/") f.fraction = true;
    if (n.arg) walk(n.arg);
    if (n.left) { walk(n.left); walk(n.right); }
  })(p.ast);
  f.subtract = p.toks.some((t) => t.meaning === "subtract");
  f.negCoef = ts.some((t) => t.mono && t.mono.c.negative && t.varPart);
  f.coefOne = ts.some((t) => t.mono && t.varPart && t.mono.c.isInt && Math.abs(t.mono.c.n) === 1);
  f.bracketTerm = f.brackets && ts.some((t) => !t.simple);
  f.squint = E.squint(p.ast);
  f.repeat = !!(f.squint && f.squint.legend.some((g) => g.count > 1));
  return f;
}
function q(s) { return `“${s}”`; }
function teachMoves(p, step) {
  const f = features(p);
  const mo = E.mainOperation(p.ast), pr = E.principal(p.ast);
  const v = f.vars[0] || "x";
  const W = [];
  let say = "", ask = [];
  if (step === 0) {
    say = `Before I do anything, I look. ${mo.text} In words, the principal operation is ${pr.op}.${f.squint ? ` If I squint, each bracket group becomes one box.` : ""}`;
    ask = ["If you were to calculate this, what would you do last?", "How many terms are there? Point to what tells you.", f.repeat ? "Does any part appear more than once?" : "Have we seen an expression shaped like this before?"];
    if (f.bracketTerm) W.push(["Students count the terms inside the brackets as separate terms.", "Cover each bracket group with a sticky note (the squint view) and count again.", "brackets-count", ["hoch"]]);
    W.push(["Students start expanding or simplifying straight away.", `Pause: ${q("No pencils until someone names the principal operation.")}`, "rush", ["hoch", "star"]]);
  } else if (step === 1) {
    say = `I box each term and keep the sign in front with it. ${f.nTerms === 1 ? "Everything is held together, so this is one term." : `That gives ${f.nTerms} terms.`}${f.like ? " Some terms have the same variable part, so I tag them as like terms." : ""}`;
    ask = [f.subtract ? "Which terms have a minus sign in front? Does the sign stay with the term?" : "Where does each term start and end?", f.bracketTerm ? "Why is the bracket group one term?" : "Which terms could be combined?"];
    if (f.subtract) W.push(["Students box the term but leave its − sign outside.", `Ask ${q("Is it +4x or −4x?")} and draw the box around the sign too.`, "sign", ["rubenstein"]]);
    if (f.like || f.nTerms > 1) W.push(["Students treat terms as like terms because they share a letter (x² and x).", "Name the full variable part of each term before combining. Build both with tiles to show they can't merge.", "unlike", ["witzel", "riccomini"]]);
  } else if (step === 2) {
    say = `In each term I name the parts. The coefficient is the number that multiplies the variable, and it includes the sign.${f.coefOne ? " When no number is written, the coefficient is 1." : ""}`;
    ask = ["What number multiplies the variable in each term?", f.subtract || f.opposite || f.negCoef ? "What is each − sign doing here: subtract, negative, or opposite?" : "Which number is a constant? How do you know?"];
    if (f.exponent) W.push([`Students call the exponent in ${v}² a coefficient, or read ${v}² as 2${v}.`, `Expand it: ${v}² is ${v} · ${v}. Ask ${q("What multiplies " + v + "?")}`, "exponent", ["macgregorStacey"]]);
    if (f.coefOne) W.push([`Students say a term like ${v} has no coefficient.`, `Write it as 1${v}: when no number is written, the coefficient is 1.`, null, ["riccomini"]]);
    if (f.negCoef || f.subtract) W.push(["Students drop the sign when naming the coefficient.", "Point to the box from Split: the sign is inside it, so it is part of the coefficient.", "sign", ["rubenstein", "hoch"]]);
    if (f.opposite) W.push(["Students read −3² or −(…) as “negative 3, squared”.", `Say ${q("the opposite of…")} and show (−3)² beside −3².`, "opp-power", ["rubenstein"]]);
  } else if (step === 3) {
    const lit = E.readLiteral(p.ast), mean = E.meaningPlain(E.readMeaning(p.ast));
    say = `Symbol by symbol: ${q(lit)}. By meaning: ${q(mean)}.`;
    ask = ["Read it to your partner so they could write it down without seeing it.", "What is the first noun in the math reading? What does it tell you?"];
    if (f.brackets) W.push(["Students skip the bracket when reading aloud (" + q("3 times x plus 2") + ").", "Partner dictation: one reads, the other writes what they hear, then compare. Say “the quantity” every time a bracket opens.", "unspoken", ["macgregorPrice", "macgregorStacey"]]);
    W.push(["Students describe it in everyday words (" + q("three x-squareds take away…") + ").", "Accept it, then revoice it in the math register and have them repeat the precise version.", null, ["moschkovich", "schleppegrell"]]);
  } else if (step === 4) {
    say = "Same expression, new form. I'll build it with tiles, then draw it, then write it, and then go the other way.";
    ask = ["What stays the same when we change forms?", "Which form shows the like terms most clearly?"];
    if (f.distrib) W.push(["Students build the outside factor's groups but only multiply the first term inside.", "Build each group in full and count the tiles of each kind aloud.", "distribute", ["witzel", "kirshner"]]);
    W.push(["Students say zero pairs “cancel”.", "Revoice: “a positive and a negative tile add to zero.”", null, ["star"]]);
    W.push(["Students can go from symbols to tiles but not back.", "Practise both directions (Match the tiles and Build it).", null, ["duval"]]);
  } else {
    say = `I predict first. Then I put the number in brackets for ${v} and work in order: brackets, exponents, multiplying and dividing, adding and subtracting.`;
    ask = ["Will the value be positive, negative or zero? How can you tell before calculating?", "Where do the brackets go when you substitute?"];
    if (f.exponent) W.push([`Students multiply before squaring (3(2)² → 6²).`, "Write the steps vertically and circle the exponent step first.", "spacing", ["landy"]]);
    W.push([`Students write 32 for 3${v} when ${v} = 2.`, `Always put the substituted value in brackets: 3(2).`, null, ["arcavi"]]);
    if (f.opposite || f.exponent) W.push([`Students get a positive answer for −${v}² with a negative ${v}.`, `Substitute with brackets, −(−3)², and read it as “the opposite of…”.`, "opp-power", ["rubenstein"]]);
  }
  return { say, ask, watch: W };
}
function teachBoxHTML(p, step) {
  const m = teachMoves(p, step);
  return `<p class="teachhead">Teaching moves</p>
    <p><b>Say:</b> ${E.esc(m.say)}</p>
    <p><b>Ask:</b></p><ul>${m.ask.map((a) => `<li>${E.esc(a)}</li>`).join("")}</ul>
    <p><b>Listen for, then respond:</b></p><ul class="lr">${m.watch.map(([l, r, mid, cs]) => `<li><span class="listen">${E.esc(l)}</span> <span class="arrow">→</span> ${E.esc(r)} <span class="refs">${mid ? miscLink(mid) + " · " : ""}${cite(...cs)}</span></li>`).join("")}</ul>`;
}

/* ---------- Mini-lesson plan ---------- */
function suggestModes(f) {
  const s = [];
  if (f.distrib) s.push("error", "same");
  if (f.brackets) s.push("say");
  if (f.like) s.push("build");
  if (f.exponent || f.subtract) s.push("spot");
  if (!s.length) s.push("spot", "say");
  return [...new Set(s)].slice(0, 3);
}
function planData(p) {
  const f = features(p), src = E.plainText(p.ast);
  const curr = [];
  if (f.like || f.distrib) curr.push("C1.4 simplify algebraic expressions");
  if (f.distrib || f.powerOfGroup) curr.push("C1.3 compare expressions for equivalence");
  if (f.exponent) curr.push("B2.2 exponents and powers");
  if (!curr.length) curr.push("C1.4 algebraic expressions");
  const focus = f.distrib ? "the distributive structure: the outside factor multiplies every term in the bracket" : f.like ? "terms and like terms" : f.brackets ? "reading brackets aloud as one group" : f.exponent ? "exponents versus coefficients" : "naming the parts of each term";
  const moves = [0, 1, 2, 3, 4, 5].map((i) => teachMoves(p, i));
  const watch = []; const seen = new Set();
  moves.forEach((m) => m.watch.forEach((w) => { if (!seen.has(w[0])) { seen.add(w[0]); watch.push(w); } }));
  return { src, f, curr, focus, moves, watch: watch.slice(0, 5), modes: suggestModes(f) };
}
function planHTML(p) {
  const d = planData(p);
  return `<div class="plangrid">
    <div><p class="scriptlabel">Expression</p><p class="math big">${E.esc(d.src)}</p>
      <p class="scriptlabel">Curriculum</p><p>${d.curr.join("; ")}</p>
      <p class="scriptlabel">Focus</p><p>${E.esc(d.focus)}</p>
      <p class="scriptlabel">Learning goal</p><p>I can decode ${E.esc(d.src)}: name its principal operation, box its terms, name its parts, read it aloud precisely, and check it with a number.</p></div>
    <div><p class="scriptlabel">I do · model (4–5 min)</p><ol>${d.moves.slice(0, 4).map((m, i) => `<li><b>${SIX[i][0]}.</b> ${E.esc(m.say)}</li>`).join("")}</ol>
      <p class="scriptlabel">We do · together (5 min)</p><ul>${[d.moves[0].ask[0], d.moves[1].ask[0], d.moves[3].ask[0], d.moves[5].ask[0]].map((a) => `<li>${E.esc(a)}</li>`).join("")}</ul>
      <p class="scriptlabel">You do · practise (5 min)</p><p>${d.modes.map(modeBtn).join(" ")}</p></div>
    <div><p class="scriptlabel">Watch for</p><ul>${d.watch.map(([l, r]) => `<li><span class="listen">${E.esc(l)}</span> → ${E.esc(r)}</li>`).join("")}</ul>
      <p class="scriptlabel">Exit ticket</p><p>“The principal operation of ${E.esc(d.src)} is ___, so it is a ___ with ___ terms. One way to read it aloud is ___.”</p></div>
  </div>`;
}
function planText(p) {
  const d = planData(p);
  const L = [];
  L.push(`MINI-LESSON: Decoding ${d.src} (10–15 min)`, `Curriculum: ${d.curr.join("; ")}`, `Focus: ${d.focus}`,
    `Learning goal: I can decode ${d.src}: name its principal operation, box its terms, name its parts, read it aloud precisely, and check it with a number.`, "",
    "I DO (model, 4–5 min)");
  d.moves.slice(0, 4).forEach((m, i) => L.push(`  ${SIX[i][0]}: ${m.say}`));
  L.push("", "WE DO (together, 5 min)");
  [d.moves[0].ask[0], d.moves[1].ask[0], d.moves[3].ask[0], d.moves[5].ask[0]].forEach((a) => L.push("  - " + a));
  L.push("", "YOU DO (practise, 5 min): Algebra Decoder → Practice → " + d.modes.map((k) => MODE_NAMES[k]).join(", "), "", "WATCH FOR");
  d.watch.forEach(([l, r]) => L.push(`  - ${l} → ${r}`));
  L.push("", `EXIT TICKET: "The principal operation of ${d.src} is ___, so it is a ___ with ___ terms. One way to read it aloud is ___."`);
  return L.join("\n");
}

/* ---------- Teach the routine: six lessons ---------- */
const ROUTINE = [
  { goal: "Students name the principal operation and count the terms before calculating anything.", ex: "3(x + 1)² − 5(x + 1)",
    model: "Before I do anything, I look. I see one − sign outside brackets, so the principal operation is subtraction and there are two terms. If I squint, it's 3A² − 5A, where A is the group x + 1, and A appears twice.",
    ask: ["If you calculated this, what would you do last?", "How many terms? Point to what tells you.", "Does any part repeat?"],
    look: ["Points only to + and − signs outside brackets", "Uses “principal operation” or “last step”", "Waits to simplify until the structure is named"],
    watch: ["rush", "brackets-count"], modes: ["spot", "error"], cites: ["hoch", "kirshner", "star"] },
  { goal: "Students box each term with its sign and keep bracket groups whole.", ex: "5 − 4x + 2(x − 3)",
    model: "I box each term and the sign in front travels with it: 5, then −4x, then +2(x − 3). The bracket keeps 2(x − 3) together as one term until I expand it.",
    ask: ["Is it 4x or −4x?", "Why is 2(x − 3) one term?", "Which terms could be combined?"],
    look: ["Each box includes its sign", "Bracket groups stay inside one box", "Explains like terms by their variable part"],
    watch: ["sign", "brackets-count", "unlike"], modes: ["spot", "build"], cites: ["hoch", "star"] },
  { goal: "Students name the coefficient, variable, exponent and constant of each term, and the job of each − sign.", ex: "5 − 4x² + x",
    model: "In −4x², the coefficient is −4, the variable is x, and the exponent is 2. In x, the coefficient is 1 even though no number is written. The first − here means subtract.",
    ask: ["What multiplies x² here?", "What is this − sign doing: subtract, negative or opposite?", "Which part is the constant?"],
    look: ["Includes the sign in the coefficient", "Distinguishes exponent from coefficient", "Uses the math word for each part"],
    watch: ["exponent", "sign", "letters", "opp-power"], modes: ["spot", "words"], cites: ["riccomini", "rubenstein"] },
  { goal: "Students read expressions aloud precisely, including brackets, and say what the expression does.", ex: "3(x + 2)",
    model: "In everyday words: three groups of x and 2. Symbol by symbol: 3 times the quantity x plus 2. By meaning: the product of 3 and the sum of x and 2. The first noun, product, tells me the principal operation.",
    ask: ["Read it so your partner can write it without seeing it.", "What's the first noun in your math reading?", "How would it sound without “the quantity”?"],
    look: ["Says “the quantity” when a bracket opens", "Partner can write the expression from the reading", "Moves from everyday words to math words"],
    watch: ["unspoken", "lessthan"], modes: ["say", "write"], cites: ["schleppegrell", "macgregorPrice", "moschkovich"] },
  { goal: "Students convert the expression to tiles, a table, a graph or words, and back again.", ex: "2(x − 3) + 3x",
    model: "Two groups of one x and three negative ones, plus three x's. Combined, that's 5 x-tiles and 6 negative ones: 5x − 6. Now I go the other way: what expression do these tiles show?",
    ask: ["What stays the same when we change forms?", "Which form shows the like terms best?", "Can you go back from the tiles to symbols?"],
    look: ["Builds every group in full", "Says zero pairs “add to zero”", "Converts in both directions"],
    watch: ["distribute", "unlike"], modes: ["tiles", "build", "same"], cites: ["duval", "witzel"] },
  { goal: "Students predict, substitute using brackets, and use the result to check their reading.", ex: "−x² + 3x",
    model: "Let x = −2. I predict: −x² will be negative and 3x will be negative, so the value is negative. Substitute with brackets: −(−2)² + 3(−2) = −4 − 6 = −10. My prediction holds.",
    ask: ["Positive, negative or zero? How can you tell before calculating?", "Where do the brackets go when you substitute?", "Does the result match your reading?"],
    look: ["Makes a prediction first", "Brackets every substituted value", "Squares before taking the opposite"],
    watch: ["opp-power", "spacing"], modes: ["error", "same"], cites: ["arcavi"] },
];
function buildRoutine() {
  $("#seq").innerHTML = SIX.map((s, i) => `<a href="#routine" class="seqstep" data-jump="${i}"><span class="sn">${i + 1}</span><b>Lesson ${i + 1}</b><span>${s[0]}</span></a>`).join("");
  $("#seq").addEventListener("click", (e) => { const a = e.target.closest("[data-jump]"); if (!a) return; e.preventDefault(); document.getElementById("lesson-" + a.dataset.jump).scrollIntoView({ block: "start" }); });
  $("#lessons").innerHTML = ROUTINE.map((r, i) => {
    let exH = ""; try { exH = `<span class="colour math">${exprHTML(E.parse(r.ex))}</span>`; } catch (e) { exH = r.ex; }
    return `<article class="lesson" id="lesson-${i}">
      <header><span class="sn">${i + 1}</span><div><h3>${SIX[i][0]}: ${SIX[i][1]}</h3><p class="note">${r.goal}</p></div></header>
      <div class="lessongrid">
        <div><p class="scriptlabel">Model with</p><p class="lessonex">${exH}</p>
          <p class="scriptlabel">Think aloud</p><p class="think">“${E.esc(r.model)}”</p>
          <button type="button" class="btn small ghost" data-model-ex="${E.esc(r.ex)}">Open in Model it</button></div>
        <div><p class="scriptlabel">Ask</p><ul>${r.ask.map((a) => `<li>${E.esc(a)}</li>`).join("")}</ul>
          <p class="scriptlabel">Look-fors</p><ul class="checks">${r.look.map((a) => `<li>${E.esc(a)}</li>`).join("")}</ul>
          <p class="scriptlabel">Sentence starter for students</p><p>“${SIX[i][3]}”</p></div>
        <div><p class="scriptlabel">Watch for</p><ul>${r.watch.map((m) => `<li>${miscLink(m)}</li>`).join("")}</ul>
          <p class="scriptlabel">Students practise</p><p>${r.modes.map(modeBtn).join(" ")}</p>
          <p class="scriptlabel">Research</p><p class="refs">${cite(...r.cites)}</p></div>
      </div></article>`;
  }).join("");
  $("#lessons").addEventListener("click", (e) => { const b = e.target.closest("[data-model-ex]"); if (b) { $("#exprIn").value = b.dataset.modelEx; go("decode"); decode(true); window.scrollTo({ top: 0 }); } });
}

/* ---------- Respond: misconceptions ---------- */
const MISC = [
  { id: "distribute", step: 4, title: "Multiplying only the first term in a bracket", looks: "−3x(4x² − 5) = −12x³ − 5", why: "EQAO's 2022–23 Grade 9 report names this as a common choice among students at Level 2. Rules that look visually neat, like a(b − c) = ab − ac, are easy to recognize and easy to apply carelessly.", move: "Use an area model or tiles so each term inside the bracket gets its own rectangle. Have students draw an arrow from the outside factor to every term inside, then check the arrow count against the number of terms.", say: "−3x multiplies every term in the bracket.", modes: ["error", "same"], cites: ["kirshner", "star", "witzel"] },
  { id: "power-sum", step: 5, title: "Squaring each term of a sum", looks: "(x + 3)² = x² + 9", why: "Students over-apply visually neat rules such as (xy)² = x²y² to sums, where they don't hold.", move: "Test with a number: (1 + 3)² = 16 but 1² + 9 = 10. Then write (x + 3)(x + 3) and use an area model.", say: "A power of a product splits. A power of a sum does not.", modes: ["error", "same"], cites: ["kirshner", "arcavi"] },
  { id: "exponent", step: 2, title: "Confusing exponents and coefficients", looks: "x³ written for 3x; x² read as 2x", why: "In MacGregor & Stacey's data, writing x³ for 3x rose from 5% in Year 7 to 18% in Year 10, a sign of interference from newly learned rules.", move: "Contrast side by side: 3x = x + x + x and x³ = x · x · x. Substitute x = 2 into both.", say: "3x is 3 times x. x cubed is x times x times x.", modes: ["spot", "error"], cites: ["macgregorStacey"] },
  { id: "letters", step: 2, title: "Treating letters as labels or codes", looks: "h = 8 because h is the 8th letter; 5c means “5 cats”", why: "Students borrow from codes and puzzles, and some materials introduce letters as short forms of words, which leaves lasting misreadings.", move: "Introduce letters as numbers: “h is Con's height in cm. It could be 150.” Avoid examples where letters stand for objects (a for apples).", say: "The letter stands for a number.", modes: ["error"], cites: ["macgregorStacey"] },
  { id: "unspoken", step: 3, title: "Leaving brackets unspoken", looks: "Reads 3(x + 2) as “3 times x plus 2”; writes 3x + 4 for “3 times the sum of x and 4”", why: "Students who are less aware of ambiguity in language rarely reach high algebra scores, and explicit teaching of brackets and ambiguity has improved results sharply.", move: "Partner dictation: one student reads aloud, the other writes what they hear, then they compare. Say “the quantity” every time a bracket opens.", say: "3 times the quantity x plus 2.", modes: ["say", "write"], cites: ["macgregorPrice", "macgregorStacey"] },
  { id: "lessthan", step: 3, title: "Reversing order with “less than”", looks: "5 − x for “5 less than x”", why: "English word order doesn't always match symbol order, and awareness of syntax is linked to success in algebra.", move: "Test with a number: 5 less than 10 is 5. Does 5 − 10 give 5? Flag order-flipping phrases on the signal-word chart.", say: "5 less than x means start at x and take away 5.", modes: ["write"], cites: ["macgregorPrice"] },
  { id: "sign", step: 1, title: "Separating a term from its sign", looks: "“The coefficient of x in 5 − 4x is 4.”", why: "The − sign plays several roles (subtract, negative, opposite), and students often read it only as subtract.", move: "Box each term with the sign in front, then ask what multiplies x inside the box.", say: "The sign in front belongs to the term.", modes: ["spot"], cites: ["rubenstein", "hoch"] },
  { id: "unlike", step: 1, title: "Combining unlike terms", looks: "3 + 2x = 5x; 3x² + x = 4x³", why: "In everyday talk, “like” means similar. In math, like terms need exactly the same variable part.", move: "Build with tiles: unit tiles and x tiles can't merge into one kind. Have students name the variable part of each term before combining.", say: "Like terms have the same variables with the same exponents.", modes: ["build", "tiles", "words"], cites: ["witzel", "riccomini"] },
  { id: "opp-power", step: 5, title: "Squaring the negative sign", looks: "−3² = 9; −x² = 9 when x = −3", why: "Rubenstein & Thompson open their article with a related slip: getting −3 for −x when x = −3.", move: "Read it aloud as “the opposite of 3 squared”. When substituting, always bracket the value: −(−3)².", say: "The opposite of 3 squared is −9.", modes: ["error", "spot"], cites: ["rubenstein"] },
  { id: "spacing", step: 5, title: "Letting spacing set the order", looks: "2+3 × 4 = 20", why: "Visual grouping that clashes with the order of operations makes even adults less accurate.", move: "Write with tight spacing for multiplication and wide spacing for + and −. Ask students to rewrite crowded expressions with structural spacing.", say: "Multiply before adding, however it's spaced.", modes: ["error"], cites: ["landy"] },
  { id: "brackets-count", step: 0, title: "Counting terms inside brackets", looks: "Says 2(x − 3) + 3x has 4 terms", why: "Seeing a bracket group as a single object is part of structure sense, and few students do it spontaneously.", move: "Squint: cover each bracket group with a sticky note and count again.", say: "A bracket group is one term until it's expanded.", modes: ["spot"], cites: ["hoch"] },
  { id: "rush", step: 0, title: "Manipulating before reading", looks: "Starts expanding or calculating before reading the whole expression", why: "Structure sense was rare even among Grade 11 students, and the researchers suggest teaching students to look before they do.", move: "Make Scan routine: no pencils until someone names the principal operation and the number of terms.", say: "What is the principal operation?", modes: ["error"], cites: ["hoch", "star"] },
];
const SCEN = [
  { ctx: "Decoding 5 − 4x, a student says: “The coefficient of x is 4.”", opts: [
    ["“Cover everything except the box around −4x. What number multiplies x inside that box?”", true, "It sends the student back to the term boxes from Split so they find the sign themselves."],
    ["“Close. Don't forget the negative.”", false, "It gives the answer without building the habit of reading the sign as part of the term."],
    ["“No, it's −4.”", false, "It's correct but shuts down the student's thinking."],
    ["“Coefficients can be negative. Memorize that.”", false, "It's a rule to remember, not a way to read the expression."]], cites: ["hoch", "rubenstein"] },
  { ctx: "Simplifying x + 5 − 5, a student says: “The fives cancel.”", opts: [
    ["“Yes. Can you say it another way? What do +5 and −5 add to?”", true, "It accepts the idea and revoices it in precise language: they add to zero."],
    ["“Correct, they cancel out.”", false, "It reinforces vague language that hides the inverse operation."],
    ["“We don't say cancel in this class.”", false, "It corrects the word without showing the meaning behind it."],
    ["“Right, so cross them out.”", false, "Crossing out is a visual shortcut that later gets misapplied, as in (x + 5)/5."]], cites: ["star"] },
  { ctx: "Asked for “3 times the sum of x and 4”, a student writes 3x + 4.", opts: [
    ["“Read your expression back to me. Does it say the same thing as the words?”", true, "Reading back exposes the missing bracket and builds the habit of checking."],
    ["“You forgot the brackets.”", false, "It fixes this answer but doesn't help next time."],
    ["“Always put brackets around sums.”", false, "Over-general: x + 4 alone needs no brackets."],
    ["“Expand it to 3x + 12 next time.”", false, "It skips the reading problem entirely."]], cites: ["macgregorStacey", "macgregorPrice"] },
  { ctx: "A student writes (x + 3)² = x² + 9.", opts: [
    ["“Try x = 1 in both. Do you get the same value?”", true, "A substitution check lets the student find the problem and motivates a better rule."],
    ["“Remember FOIL.”", false, "It names a procedure without addressing why squaring each term fails."],
    ["“That rule only works for multiplication.”", false, "It's true but abstract. Pair it with a test the student can run."],
    ["“That's a common mistake. Fix it.”", false, "It gives no route to understanding."]], cites: ["arcavi", "kirshner"] },
  { ctx: "An English language learner describes 3x² − 2x as “three x-squareds, then take away two x's.”", opts: [
    ["“Yes, that's exactly it. In math language we say ‘the difference of 3x² and 2x.’ Can you say that with me?”", true, "It values the everyday reading as real understanding, then builds the math register together."],
    ["“Use the proper words, please.”", false, "It treats correct reasoning as a language deficit."],
    ["“Don't worry about saying it. Just simplify.”", false, "It removes the student from mathematical discourse."],
    ["“Look up ‘difference’ in the glossary.”", false, "Vocabulary out of context separates language from the reasoning."]], cites: ["moschkovich", "schleppegrell"] },
  { ctx: "A student says David's height is 18 cm because “h is the 8th letter, so h = 8.”", opts: [
    ["“h stands for Con's height in centimetres. Could Con be 150 cm tall? Then how tall is David?”", true, "It reframes the letter as an unknown number and lets the student generalize to h + 10."],
    ["“Letters don't have number values.”", false, "Confusing: letters stand for numbers, just not alphabet positions."],
    ["“The answer is h + 10.”", false, "It gives the answer without addressing the belief."],
    ["“That's from a puzzle game, not math.”", false, "It names the source but doesn't build a new meaning."]], cites: ["macgregorStacey"] },
  { ctx: "Several students expand −3x(4x² − 5) as −12x³ − 5.", opts: [
    ["Show that solution beside a correct one, labelled, and ask pairs where and why they differ.", true, "Comparing labelled incorrect and correct work, with explanation, supports conceptual understanding."],
    ["Re-teach the distributive property from the start.", false, "Possible, but it misses the chance to work from students' own reasoning."],
    ["Mark it wrong and move on.", false, "The error will likely recur."],
    ["Tell students to multiply “every term”.", false, "A useful slogan, but stronger when students discover it by comparing."]], cites: ["booth", "star"] },
  { ctx: "Given 3(x + 1)² − 5(x + 1), the class immediately starts expanding.", opts: [
    ["Pause: “Pencils down. What's the principal operation? Does anything repeat?”", true, "Looking before doing is what structure sense depends on. Here the repeat (x + 1) changes the best approach."],
    ["Let them expand. It's good practice.", false, "Practice yes, but it misses the structure lesson."],
    ["Show them the fastest method.", false, "Telling the structure takes away the chance to notice it."],
    ["Remind them of BEDMAS.", false, "Order of operations is for evaluating. The issue here is reading structure."]], cites: ["hoch", "star"] },
];
const S = { i: -1, right: 0, tried: 0 };
function buildRespond() {
  const steps = ["All", ...SIX.map((s) => s[0])];
  $("#miscFilter").innerHTML = steps.map((s, i) => `<button type="button" class="toggle" data-f="${i - 1}" aria-pressed="${i === 0}">${s}</button>`).join("");
  $("#miscFilter").addEventListener("click", (e) => { const b = e.target.closest("[data-f]"); if (!b) return; $$("#miscFilter button").forEach((x) => x.setAttribute("aria-pressed", x === b)); const f = +b.dataset.f; $$("#misc .mcard").forEach((c) => (c.style.display = f < 0 || +c.dataset.step === f ? "" : "none")); });
  $("#misc").innerHTML = MISC.map((m) => `<article class="mcard" id="m-${m.id}" data-step="${m.step}">
    <p class="mstep">${SIX[m.step][0]}</p><h3>${m.title}</h3>
    <p class="looks"><span class="scriptlabel">Looks like</span><span class="math">${E.esc(m.looks)}</span></p>
    <p><b>Why it happens:</b> ${E.esc(m.why)}</p>
    <p><b>Teaching move:</b> ${E.esc(m.move)}</p>
    <p class="sayline"><b>Say:</b> “${E.esc(m.say)}”</p>
    <p class="refs">Students practise: ${m.modes.map(modeBtn).join(" ")}</p>
    <p class="refs">${cite(...m.cites)}</p></article>`).join("");
  $("#scard").addEventListener("click", onScen);
  nextScen();
}
function nextScen() {
  S.i = (S.i + 1) % SCEN.length;
  const s = SCEN[S.i];
  $("#scard").innerHTML = `<p class="note">Scenario ${S.i + 1} of ${SCEN.length}</p><p class="qprompt">${E.esc(s.ctx)}</p><p>What would you say or do?</p>
    <div class="opts">${shuffle(s.opts.map((o, k) => k)).map((k) => `<button type="button" class="opt" data-s="${k}">${E.esc(s.opts[k][0])}</button>`).join("")}</div><div id="sfb" class="fb" aria-live="polite"></div>`;
}
function onScen(e) {
  if (e.target.closest("[data-snext]")) { nextScen(); return; }
  const b = e.target.closest("[data-s]"); if (!b || b.disabled) return;
  const s = SCEN[S.i], k = +b.dataset.s, ok = s.opts[k][1];
  S.tried++; if (ok) S.right++;
  $("#tRight").textContent = S.right; $("#tTried").textContent = S.tried;
  $$("#scard .opt").forEach((x) => { x.disabled = true; const j = +x.dataset.s; if (s.opts[j][1]) x.classList.add("right"); else if (j === k) x.classList.add("wrong"); });
  const fb = $("#sfb"); fb.className = "fb show " + (ok ? "good" : "bad");
  fb.innerHTML = `<h4>${ok ? "That matches the research." : "There's a stronger move."}</h4>
    <ul class="plain">${s.opts.map(([t, good, w]) => `<li><b>${good ? "Strong:" : "Weaker:"}</b> ${E.esc(t)} <span class="note">${E.esc(w)}</span></li>`).join("")}</ul>
    <p class="refs">${cite(...s.cites)}</p><div class="qactions"><button type="button" class="btn small" data-snext="1">Next scenario</button></div>`;
}

/* ---------- Language ---------- */
const TALK = [
  ["“The 3s cancel.”", "“3 and −3 add to zero.” / “3 divided by 3 is 1.”", "Names the inverse operation that does the work.", true],
  ["“Take out the x.”", "“Factor x from the expression.”", "Uses the name of the operation.", true],
  ["“Times the bracket.”", "“Times the quantity x plus 2.”", "Tells a listener where the group starts.", false],
  ["“Minus 4” (for the number −4)", "“Negative 4.”", "Separates the number's sign from the subtract operation.", false],
  ["“x two”", "“x squared.”", "Says what the exponent does.", false],
  ["“Solve this expression.”", "“Simplify” or “evaluate this expression.”", "Equations are solved; expressions are simplified or evaluated.", false],
  ["“Move the 5 to the other side.”", "“Subtract 5 from both sides.”", "Describes an operation, not a physical move.", false],
  ["“Get rid of the brackets.”", "“Expand: multiply each term inside by the factor outside.”", "Keeps the distributive structure in view.", false],
];
function buildLanguageExtras() {
  $("#talk").innerHTML = TALK.map(([a, b, w, ies]) => `<tr><td>${E.esc(a)}</td><td><b>${E.esc(b)}</b></td><td>${E.esc(w)}${ies ? ` <span class="refs">(example from ${cite("star")})</span>` : ""}</td></tr>`).join("");
  $("#talkCite").innerHTML = `(${cite("star", "schleppegrell")})`;
  $("#vocabMoves").innerHTML = [
    ["Teach key words explicitly and often.", "Introduce a word with its meaning, a colour-coded example and a non-example, then return to it in short daily reviews.", ["riccomini"]],
    ["Ask students to say it in their own words.", "Restating a definition and making a visual for it are part of learning a word, not extras.", ["riccomini"]],
    ["Set the everyday meaning beside the math meaning.", "Product, term, degree, power and like all mean something less precise in everyday talk.", ["riccomini", "shanahan"]],
    ["Keep words inside reasoning.", "Vocabulary lists cut language off from thinking. Use the words while decoding and discussing, and accept everyday words as a starting point.", ["moschkovich"]],
    ["Play with the words.", "Short sorting games (like Word check in Practice) give the many exposures new words need.", ["riccomini"]],
  ].map(([h, t, c]) => `<li><b>${h}</b> ${t} <span class="refs">(${cite(...c)})</span></li>`).join("");
}

/* ---------- Start ---------- */
function buildStart() {
  const p = E.parse("3(x + 1)² − 5(x + 1)");
  const el = $("#startExpr");
  el.innerHTML = exprHTML(p, { termSet: termSetOf(p) });
  decorate(el, { parsed: p });
  $("#facts").innerHTML = [
    ["Reading predicts algebra.", "Among more than 1,500 students aged 11–15, very few with low awareness of symbols, syntax and ambiguity reached high algebra scores.", ["macgregorPrice"]],
    ["Explicit teaching works.", "At one school, lessons on grouping, brackets and ambiguity raised success from 31% to 81%.", ["macgregorStacey"]],
    ["Layout shapes reading.", "Spacing that clashed with the order of operations cut adults' accuracy by about 39 percentage points.", ["landy"]],
    ["Structure sense is rare.", "Even in Grade 11, few students looked at structure before manipulating, though brackets helped.", ["hoch"]],
    ["Looks can mislead.", "Students learn visually neat rules easily, then over-apply them to false look-alikes like (x + y)² = x² + y².", ["kirshner"]],
    ["It shows up on EQAO.", "EQAO's 2022–23 Grade 9 report found many Level 2 students multiplied only the first term in −3x(4x² − 5).", []],
  ].map(([h, t, c]) => `<li><b>${h}</b> ${t}${c.length ? ` <span class="refs">(${cite(...c)})</span>` : ""}</li>`).join("");
}
