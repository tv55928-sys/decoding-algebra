"use strict";
/* ============================================================
   Algebra Decoder engine — pure functions, no DOM.
   Parse → roles → terms → readings → polynomial → steps.
   ============================================================ */

const MINUS = "−";

class MathError extends Error {
  constructor(msg, pos) { super(msg); this.pos = pos; this.friendly = true; }
}

function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { const t = a % b; a = b; b = t; } return a || 1; }

class Fr {
  constructor(n, d) {
    if (d === undefined) d = 1;
    if (d === 0) throw new MathError("This divides by zero, so it has no value.");
    if (d < 0) { n = -n; d = -d; }
    const g = gcd(n, d);
    this.n = n / g; this.d = d / g;
    if (!Number.isSafeInteger(this.n) || !Number.isSafeInteger(this.d))
      throw new MathError("These numbers get too big to show exactly.");
  }
  add(o) { return new Fr(this.n * o.d + o.n * this.d, this.d * o.d); }
  sub(o) { return new Fr(this.n * o.d - o.n * this.d, this.d * o.d); }
  mul(o) { return new Fr(this.n * o.n, this.d * o.d); }
  div(o) { if (o.n === 0) throw new MathError("This divides by zero, so it has no value."); return new Fr(this.n * o.d, this.d * o.n); }
  neg() { return new Fr(-this.n, this.d); }
  abs() { return new Fr(Math.abs(this.n), this.d); }
  pow(e) {
    if (e === 0) { if (this.n === 0) throw new MathError("0 to the power of 0 has no agreed value."); return new Fr(1); }
    const base = e < 0 ? new Fr(1).div(this) : this;
    let r = new Fr(1);
    for (let i = 0; i < Math.abs(e); i++) r = r.mul(base);
    return r;
  }
  get isInt() { return this.d === 1; }
  get zero() { return this.n === 0; }
  get negative() { return this.n < 0; }
  eq(o) { return this.n === o.n && this.d === o.d; }
  valueOf() { return this.n / this.d; }
  toString() { return this.d === 1 ? String(this.n) : this.n + "/" + this.d; }
  static parse(s) {
    if (s.indexOf(".") < 0) return new Fr(parseInt(s, 10));
    const [a, b = ""] = s.split(".");
    return new Fr(parseInt((a || "0") + b, 10), Math.pow(10, b.length));
  }
}

/* ---------- Tokenizer ---------- */
const SUP_IN = { "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4", "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9", "⁻": "-" };
const SUP_OUT = { "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹", "-": "⁻" };
const OPMAP = { "+": "+", "-": "-", "−": "-", "–": "-", "*": "*", "×": "*", "·": "*", "⋅": "*", "/": "/", "÷": "/", "^": "^" };

function tokenize(src) {
  const toks = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (/\s/.test(c)) { i++; continue; }
    if (/[0-9.]/.test(c)) {
      let j = i; while (j < src.length && /[0-9.]/.test(src[j])) j++;
      const t = src.slice(i, j);
      if (t === "." || (t.match(/\./g) || []).length > 1) throw new MathError(`"${t}" isn't a number I can read.`, i);
      toks.push({ k: "num", t, raw: t, pos: i }); i = j; continue;
    }
    if (c in SUP_IN) {
      let j = i, s = "";
      while (j < src.length && src[j] in SUP_IN) { s += SUP_IN[src[j]]; j++; }
      toks.push({ k: "sup", t: s, raw: src.slice(i, j), pos: i }); i = j; continue;
    }
    if (/[a-zA-Z]/.test(c)) { toks.push({ k: "var", t: c, raw: c, pos: i }); i++; continue; }
    if (c in OPMAP) { toks.push({ k: "op", t: OPMAP[c], raw: c, pos: i }); i++; continue; }
    if (c === "(" || c === "[") { toks.push({ k: "lp", t: "(", raw: c, pos: i }); i++; continue; }
    if (c === ")" || c === "]") { toks.push({ k: "rp", t: ")", raw: c, pos: i }); i++; continue; }
    if (c === "=") throw new MathError("That has an equals sign, so it's an equation. This tool decodes expressions: try one side at a time.", i);
    throw new MathError(`I don't recognise "${c}". Use numbers, letters, + − × ÷ ^ and brackets.`, i);
  }
  return toks;
}

/* ---------- Parser ----------
   expr  := term (('+'|'-') term)*
   term  := unary (('*'|'/') unary | implicit power)*
   unary := ('-'|'+') unary | power
   power := primary ('^' unary | superscript)?
*/
function parse(src) {
  const toks = tokenize(src);
  if (!toks.length) throw new MathError("Type an expression to decode.");
  let p = 0, nid = 0;
  const peek = () => toks[p];
  const mk = (o) => { o.id = nid++; return o; };
  const missing = (tok) => new MathError(`Something is missing after "${tok.raw}".`, tok.pos);

  function expr() {
    let left = term();
    while (peek() && peek().k === "op" && (peek().t === "+" || peek().t === "-")) {
      const ti = p, tok = toks[p++];
      if (!peek()) throw missing(tok);
      const right = term();
      left = mk({ type: "bin", op: tok.t, left, right, tok: ti });
    }
    return left;
  }
  function term() {
    let left = unary();
    for (;;) {
      const t = peek();
      if (!t) break;
      if (t.k === "op" && (t.t === "*" || t.t === "/")) {
        const ti = p; p++;
        if (!peek()) throw missing(t);
        const right = unary();
        left = mk({ type: "bin", op: t.t, left, right, tok: ti });
        continue;
      }
      if (t.k === "var" || t.k === "lp") {
        const right = power();
        left = mk({ type: "bin", op: "*", implicit: true, left, right, tok: -1 });
        continue;
      }
      if (t.k === "num") throw new MathError(`Two numbers sit side by side near "${t.raw}". Add an operation between them.`, t.pos);
      break;
    }
    return left;
  }
  function unary() {
    const t = peek();
    if (t && t.k === "op" && (t.t === "-" || t.t === "+")) {
      const ti = p; p++;
      if (!peek()) throw missing(t);
      const arg = unary();
      return t.t === "+" ? arg : mk({ type: "neg", arg, tok: ti });
    }
    return power();
  }
  function power() {
    const base = primary();
    const t = peek();
    if (t && t.k === "sup") {
      const ti = p; p++;
      if (!/^-?\d+$/.test(t.t)) throw new MathError("That superscript isn't a whole number.", t.pos);
      const ex = mk({ type: "num", value: new Fr(parseInt(t.t, 10)), text: t.t, tok: ti, sup: true });
      return mk({ type: "bin", op: "^", left: base, right: ex, tok: ti, sup: true });
    }
    if (t && t.k === "op" && t.t === "^") {
      const ti = p; p++;
      if (!peek()) throw new MathError("Add an exponent after ^.", t.pos);
      const ex = unary();
      return mk({ type: "bin", op: "^", left: base, right: ex, tok: ti });
    }
    return base;
  }
  function primary() {
    const t = toks[p++];
    if (!t) throw new MathError("Something is missing at the end.");
    if (t.k === "num") return mk({ type: "num", value: Fr.parse(t.t), text: t.t, tok: p - 1 });
    if (t.k === "var") return mk({ type: "var", name: t.t, tok: p - 1 });
    if (t.k === "lp") {
      const open = p - 1;
      if (peek() && peek().k === "rp") throw new MathError("These brackets are empty.", t.pos);
      const e = expr();
      const c = toks[p++];
      if (!c || c.k !== "rp") throw new MathError("A bracket was opened but never closed.", t.pos);
      e.paren = (e.paren || 0) + 1;
      e.lp = (e.lp || []).concat(open);
      e.rp = (e.rp || []).concat(p - 1);
      return e;
    }
    if (t.k === "rp") throw new MathError("There's a closing bracket with no opening bracket.", t.pos);
    if (t.k === "sup") throw new MathError("An exponent needs a base in front of it.", t.pos);
    throw new MathError(`"${t.raw}" needs something in front of it.`, t.pos);
  }

  const ast = expr();
  if (p < toks.length) {
    const t = toks[p];
    if (t.k === "rp") throw new MathError("There's a closing bracket with no opening bracket.", t.pos);
    throw new MathError(`I couldn't read from "${t.raw}" on.`, t.pos);
  }
  const parsed = { src, toks, ast };
  assignRoles(parsed);
  return parsed;
}

/* ---------- Tree helpers ---------- */
function isBin(n, op) { return n && n.type === "bin" && (!op || n.op === op); }
function containsVar(n) {
  if (!n) return false;
  if (n.type === "var") return true;
  if (n.type === "num") return false;
  if (n.type === "neg") return containsVar(n.arg);
  return containsVar(n.left) || containsVar(n.right);
}
function varsIn(n, s = new Set()) {
  if (n.type === "var") s.add(n.name);
  else if (n.type === "neg") varsIn(n.arg, s);
  else if (n.type === "bin") { varsIn(n.left, s); varsIn(n.right, s); }
  return s;
}
function flatMul(n) {
  if (isBin(n, "*")) {
    const out = [];
    for (const k of [n.left, n.right]) { if (isBin(k, "*") && !k.paren) out.push(...flatMul(k)); else out.push(k); }
    return out;
  }
  return [n];
}
/* flatten a +/- chain into signed terms, without crossing brackets */
function flatSum(n, sign = 1, opTok = null, out = []) {
  if (isBin(n) && (n.op === "+" || n.op === "-")) {
    const sub = (k) => isBin(k) && (k.op === "+" || k.op === "-") && !k.paren;
    if (sub(n.left)) flatSum(n.left, sign, opTok, out); else out.push({ sign, node: n.left, opTok });
    const s2 = n.op === "-" ? -sign : sign;
    if (sub(n.right)) flatSum(n.right, s2, n.tok, out); else out.push({ sign: s2, node: n.right, opTok: n.tok });
    return out;
  }
  out.push({ sign, node: n, opTok }); return out;
}
function topTerms(ast) {
  if (isBin(ast) && (ast.op === "+" || ast.op === "-") && !ast.paren) return flatSum(ast);
  return [{ sign: 1, node: ast, opTok: null }];
}
function isNumNode(n, v) { return n && n.type === "num" && (v === undefined || (n.value.isInt && n.value.n === v)); }
function isCoefLike(n) { return !n.paren && (n.type === "num" || (n.type === "neg" && n.arg.type === "num" && !n.arg.paren)); }
function isVarPow(n) {
  if (n.paren) return false;
  if (n.type === "var") return true;
  if (isBin(n, "^")) return n.left.type === "var" && !n.left.paren && n.right.type === "num";
  if (isBin(n, "*")) return isVarPow(n.left) && isVarPow(n.right);
  return false;
}
/* A "chunk" is a simple monomial the eye can take in at once: 3x², −5, xy */
function isChunk(n) {
  if (n.type === "num" || n.type === "var") return true;
  if (n.paren) return false;
  if (n.type === "neg") return n.arg.type === "num" && !n.arg.paren;
  if (isBin(n, "^")) return (n.left.type === "var" || n.left.type === "num") && !n.left.paren && n.right.type === "num" && n.right.value.isInt && !n.right.value.negative;
  if (isBin(n, "*")) return isChunk(n.left) && isVarPow(n.right) && !(n.left.type === "neg" && false);
  return false;
}

/* ---------- Roles (for colour-coding) ---------- */
const ROLE_NAMES = { var: "variable", coef: "coefficient", const: "constant", exp: "exponent", op: "operation", group: "bracket" };

function assignRoles(parsed) {
  const { ast, toks } = parsed;
  toks.forEach((t) => {
    t.role = t.k === "op" ? "op" : (t.k === "lp" || t.k === "rp") ? "group" : t.k === "var" ? "var" : t.k === "sup" ? "exp" : "const";
  });
  const OPMEAN = { "+": "add", "-": "subtract", "*": "multiply", "/": "divide", "^": "power" };
  (function mean(n) {
    if (n.type === "neg") { toks[n.tok].meaning = n.arg.type === "num" && !n.arg.paren ? "negative" : "opposite"; mean(n.arg); }
    else if (n.type === "bin") { if (n.tok >= 0 && !n.sup) toks[n.tok].meaning = OPMEAN[n.op]; mean(n.left); mean(n.right); }
  })(ast);
  function walk(n, ctx) {
    if (n.type === "num") {
      if (n.sup || ctx.inExp) toks[n.tok].role = "exp";
      else toks[n.tok].role = ctx.coef ? "coef" : "const";
      return;
    }
    if (n.type === "var") return;
    if (n.type === "neg") {
      walk(n.arg, ctx);
      if (n.arg.type === "num" && !n.arg.paren) toks[n.tok].role = toks[n.arg.tok].role;
      else if (ctx.inExp) toks[n.tok].role = "exp";
      return;
    }
    if (n.op === "^") {
      walk(n.left, { inExp: ctx.inExp, coef: false });
      walk(n.right, { inExp: true });
      toks[n.tok].role = "exp";
      return;
    }
    if (n.op === "*") {
      const fs = flatMul(n);
      const hasVar = fs.some(containsVar);
      fs.forEach((f) => walk(f, { inExp: ctx.inExp, coef: hasVar && isCoefLike(f) }));
      return;
    }
    walk(n.left, { inExp: ctx.inExp }); walk(n.right, { inExp: ctx.inExp });
  }
  walk(ast, { inExp: false });
}

/* ---------- Polynomials (exact, multivariate) ---------- */
function monoKey(e) { return Object.keys(e).filter((v) => e[v] !== 0).sort().map((v) => v + "^" + e[v]).join("*"); }
const Poly = {
  c(fr) { const m = new Map(); if (!fr.zero) m.set("", { c: fr, e: {} }); return m; },
  v(name) { const m = new Map(); m.set(name + "^1", { c: new Fr(1), e: { [name]: 1 } }); return m; },
  put(m, e, c) {
    const k = monoKey(e);
    if (m.has(k)) { const s = m.get(k).c.add(c); if (s.zero) m.delete(k); else m.set(k, { c: s, e }); }
    else if (!c.zero) m.set(k, { c, e });
  },
  add(a, b, sgn) { const m = new Map(); for (const [k, t] of a) m.set(k, t); for (const [, t] of b) Poly.put(m, t.e, sgn < 0 ? t.c.neg() : t.c); return m; },
  mul(a, b) {
    const m = new Map();
    for (const [, s] of a) for (const [, t] of b) {
      const e = { ...s.e }; for (const v in t.e) e[v] = (e[v] || 0) + t.e[v];
      for (const v in e) if (e[v] === 0) delete e[v];
      Poly.put(m, e, s.c.mul(t.c));
    }
    if (m.size > 80) throw new MathError("too big");
    return m;
  },
  scale(a, fr) { const m = new Map(); for (const [k, t] of a) if (!t.c.mul(fr).zero) m.set(k, { c: t.c.mul(fr), e: t.e }); return m; },
  isConst(a) { return a.size === 0 || (a.size === 1 && a.has("")); },
  constVal(a) { return a.size === 0 ? new Fr(0) : a.get("").c; },
  equal(a, b) { if (a.size !== b.size) return false; for (const [k, t] of a) if (!b.has(k) || !b.get(k).c.eq(t.c)) return false; return true; },
  vars(a) { const s = new Set(); for (const [, t] of a) for (const v in t.e) s.add(v); return [...s].sort(); },
  degree(e) { return Object.values(e).reduce((x, y) => x + y, 0); },
};
function polyRec(n) {
  switch (n.type) {
    case "num": return Poly.c(n.value);
    case "var": return Poly.v(n.name);
    case "neg": return Poly.scale(polyRec(n.arg), new Fr(-1));
    case "bin": {
      const a = polyRec(n.left), b = polyRec(n.right);
      if (n.op === "+") return Poly.add(a, b, 1);
      if (n.op === "-") return Poly.add(a, b, -1);
      if (n.op === "*") return Poly.mul(a, b);
      if (n.op === "/") {
        if (b.size !== 1) throw new MathError("not a monomial divisor");
        const [t] = b.values(); const e = {};
        for (const v in t.e) e[v] = -t.e[v];
        const inv = new Map(); inv.set(monoKey(e), { c: new Fr(1).div(t.c), e });
        return Poly.mul(a, inv);
      }
      if (n.op === "^") {
        if (!Poly.isConst(b)) throw new MathError("variable exponent");
        const ev = Poly.constVal(b);
        if (!ev.isInt || Math.abs(ev.n) > 12) throw new MathError("exponent");
        const k = ev.n;
        if (k >= 0) { let r = Poly.c(new Fr(1)); for (let i = 0; i < k; i++) r = Poly.mul(r, a); if (k === 0 && a.size === 0) throw new MathError("0^0"); return r; }
        if (a.size !== 1) throw new MathError("negative power of a sum");
        const [t] = a.values(); const e = {};
        for (const v in t.e) e[v] = t.e[v] * k;
        const m = new Map(); m.set(monoKey(e), { c: t.c.pow(k), e }); return m;
      }
    }
  }
  throw new MathError("unknown");
}
function polyOf(n) { try { return polyRec(n); } catch (e) { return null; } }

/* sort monomials: highest degree first, then alphabetical */
function sortedMonos(p) {
  return [...p.values()].sort((a, b) => {
    const d = Poly.degree(b.e) - Poly.degree(a.e); if (d) return d;
    const va = Object.keys(a.e).sort().join(""), vb = Object.keys(b.e).sort().join("");
    if (va !== vb) return va < vb ? -1 : 1;
    return (b.e[Object.keys(b.e)[0]] || 0) - (a.e[Object.keys(a.e)[0]] || 0);
  });
}
function supStr(s) { return String(s).split("").map((ch) => SUP_OUT[ch] || ch).join(""); }
function fracHTML(fr) { return `<span class="frac"><span class="fn">${Math.abs(fr.n)}</span><span class="fd">${fr.d}</span></span>`; }
function frText(fr, html) {
  const sign = fr.negative ? MINUS : "";
  if (fr.isInt) return sign + Math.abs(fr.n);
  return sign + (html ? fracHTML(fr) : `${Math.abs(fr.n)}/${fr.d}`);
}
function varPart(e, html) {
  return Object.keys(e).sort().map((v) => {
    const k = e[v];
    if (k === 1) return v;
    const ks = k < 0 ? MINUS + Math.abs(k) : String(k);
    return html ? `${v}<sup>${ks}</sup>` : v + supStr(k);
  }).join("");
}
function monoText(m, html, first = true) {
  const vp = varPart(m.e, html);
  const abs = m.c.abs();
  let coef;
  if (vp && abs.isInt && abs.n === 1) coef = "";
  else if (!abs.isInt && !html && vp) coef = `(${abs.n}/${abs.d})`;
  else coef = frText(abs, html);
  const body = coef + vp;
  if (first) return (m.c.negative ? MINUS : "") + body;
  return (m.c.negative ? ` ${MINUS} ` : " + ") + body;
}
function polyText(p, html) {
  if (!p || p.size === 0) return "0";
  return sortedMonos(p).map((m, i) => monoText(m, html, i === 0)).join("");
}

/* ---------- Exact evaluation ---------- */
function evalNode(n, env) {
  switch (n.type) {
    case "num": return n.value;
    case "var": if (!(n.name in env)) throw new MathError(`Give ${n.name} a value.`); return env[n.name];
    case "neg": return evalNode(n.arg, env).neg();
    case "bin": {
      const a = evalNode(n.left, env), b = evalNode(n.right, env);
      if (n.op === "+") return a.add(b);
      if (n.op === "-") return a.sub(b);
      if (n.op === "*") return a.mul(b);
      if (n.op === "/") return a.div(b);
      if (!b.isInt) throw new MathError("I can only work with whole-number exponents.");
      if (Math.abs(b.n) > 20) throw new MathError("That exponent is too big to show exactly.");
      return a.pow(b.n);
    }
  }
}
function tryEval(n, env) { try { return evalNode(n, env); } catch (e) { return null; } }

/* ---------- HTML renderer (shared by hero, steps, practice) ----------
   opts.roles: token array → colour classes
   opts.termSet: Map(node → index) → box each top-level term with its sign
*/
const PREC = { "+": 1, "-": 1, "*": 2, "/": 2, "^": 4 };
function precOf(n) {
  if (n.type === "bin") return PREC[n.op];
  if (n.type === "neg") return 2;
  if (n.type === "num" && (n.value.negative || (!n.value.isInt && !n.text))) return 2;
  return 9;
}
function isNegLike(n) { return n.type === "neg" || (n.type === "num" && n.value.negative); }
function needsParen(n, parent, side) {
  if (!parent) return false;
  if (n.type === "num" && n.sub) return true;
  if (parent.type === "neg") return (isBin(n) && (n.op === "+" || n.op === "-")) || isNegLike(n);
  if (parent.op === "/") return false;
  if (parent.op === "^") return side === "left" ? precOf(n) < 9 : false;
  if (parent.op === "*") return precOf(n) < 2 || (side === "right" && isNegLike(n));
  if (parent.op === "+") return side === "right" && isNegLike(n);
  if (parent.op === "-") return side === "right" && (precOf(n) <= 1 || isNegLike(n));
  return false;
}
function startsWithDigit(n) {
  if (n.paren || n.sub) return false;
  if (n.type === "num") return !n.value.negative && (n.value.isInt || !!n.text);
  if (n.type === "bin" && n.op !== "/") return startsWithDigit(n.left);
  return false;
}
function endsWithDigit(n) {
  if (n.paren || n.sub) return false;
  if (n.type === "num") return n.value.isInt || !!n.text;
  if (n.type === "neg") return endsWithDigit(n.arg);
  if (n.type === "bin" && n.op !== "^" && n.op !== "/") return endsWithDigit(n.right);
  return false;
}
function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;"); }

function renderHTML(n, opts = {}, parent = null, side = null) {
  const roles = opts.roles;
  const span = (tokIdx, text, extra = "") => {
    const r = roles && tokIdx >= 0 && roles[tokIdx] ? roles[tokIdx].role : null;
    const cls = ["tk", r ? "r-" + r : "", extra].filter(Boolean).join(" ");
    const data = r ? ` data-role="${r}" data-tok="${tokIdx}"` : "";
    return `<span class="${cls}"${data}>${text}</span>`;
  };
  let inner;
  switch (n.type) {
    case "num": {
      if (n.text !== undefined && !n.sup) inner = span(n.tok, esc(n.text));
      else if (n.sup) inner = span(n.tok, esc(n.text.replace("-", MINUS)));
      else inner = `<span class="tk${n.sub ? " subv" : ""}">${frText(n.value, true)}</span>`;
      break;
    }
    case "var": inner = n.box ? `<span class="tk chunkbox">${n.name}</span>` : span(n.tok, n.name, "v"); break;
    case "neg": inner = span(n.tok, MINUS, "sign") + renderHTML(n.arg, opts, n, "arg"); break;
    case "bin": {
      if (n.op === "^") {
        const b = renderHTML(n.left, opts, n, "left");
        const caret = n.sup ? "" : span(n.tok, "", "caret");
        inner = `${b}${caret}<sup class="ex">${renderHTML(n.right, { ...opts, inExp: true }, n, "right")}</sup>`;
        break;
      }
      if (n.op === "/") {
        const L = renderHTML(n.left, opts, n, "left"), R = renderHTML(n.right, opts, n, "right");
        inner = `<span class="frac big">${span(n.tok, "", "bar")}<span class="fn">${L}</span><span class="fd">${R}</span></span>`;
        break;
      }
      const L = renderHTML(n.left, opts, n, "left");
      let R = renderHTML(n.right, opts, n, "right");
      let opHTML;
      if (n.op === "*") {
        const clash = startsWithDigit(n.right) || (isBin(n.right, "/") && !n.right.paren && endsWithDigit(n.left));
        opHTML = n.implicit && !clash ? "" : (n.tok >= 0 ? span(n.tok, "×", "op mulop") : `<span class="tk op mulop">×</span>`);
      } else {
        const sym = n.op === "+" ? "+" : MINUS;
        opHTML = n.tok >= 0 ? span(n.tok, sym, "op addop") : `<span class="tk op addop">${sym}</span>`;
      }
      if (opts.termSet && opts.termSet.has(n.right)) {
        R = `<span class="termbox" data-term="${opts.termSet.get(n.right)}">${opHTML}${R}</span>`;
        opHTML = "";
      }
      inner = L + opHTML + R;
      if (opts.termSet && opts.termSet.has(n.left) && opts.termSet.get(n.left) === 0)
        inner = `<span class="termbox" data-term="0">${L}</span>` + opHTML + R;
      break;
    }
  }
  if (opts.termSet && !parent && opts.termSet.size === 1) inner = `<span class="termbox" data-term="0">${inner}</span>`;
  const showParen = (n.paren && !(parent && parent.op === "/")) || (!n.paren && needsParen(n, parent, side));
  if (showParen) {
    const lp = n.lp ? span(n.lp[n.lp.length - 1], "(", "br") : `<span class="tk br">(</span>`;
    const rp = n.rp ? span(n.rp[n.rp.length - 1], ")", "br") : `<span class="tk br">)</span>`;
    inner = lp + inner + rp;
  }
  return inner;
}

/* ---------- Readings ---------- */
function numSay(n) {
  if (n.text !== undefined && !n.sup) return n.text;
  const v = n.value;
  if (v.isInt) return v.negative ? "negative " + Math.abs(v.n) : String(v.n);
  return (v.negative ? "negative " : "") + Math.abs(v.n) + " over " + v.d;
}
function listSay(parts) {
  if (parts.length === 1) return parts[0];
  if (parts.length === 2) return parts[0] + " and " + parts[1];
  return parts.slice(0, -1).join(", ") + ", and " + parts[parts.length - 1];
}
function ordinal(k) { const s = ["th", "st", "nd", "rd"], v = k % 100; return k + (s[(v - 20) % 10] || s[v] || s[0]); }
const END = "‚"; // marks the end of a spoken bracket group

function readLiteral(ast) {
  function rl(n) {
    let s;
    switch (n.type) {
      case "num": s = numSay(n); break;
      case "var": s = n.name; break;
      case "neg": s = (n.arg.type === "num" || n.arg.type === "var") && !n.arg.paren ? "negative " + rl(n.arg) : "the opposite of " + rl(n.arg); break;
      case "bin":
        if (n.op === "^") {
          const b = rl(n.left), e = n.right;
          if (isNumNode(e, 2)) s = b + (n.left.paren ? " " : " ") + "squared";
          else if (isNumNode(e, 3)) s = b + " cubed";
          else s = b + " to the power of " + rl(e);
        } else if (n.op === "*") {
          const L = rl(n.left), R = rl(n.right);
          if (n.implicit && (isCoefLike(n.left) || isVarPow(n.left)) && isVarPow(n.right)) {
            s = (isCoefLike(n.left) && /^[0-9.]+$/.test(L.replace("negative ", ""))) ? L + R : L + " " + R;
          } else s = L + " times " + R;
        } else if (n.op === "/") s = rl(n.left) + " divided by " + rl(n.right);
        else s = rl(n.left) + (n.op === "+" ? " plus " : " minus ") + rl(n.right);
    }
    if (n.paren && n.type !== "num" && n.type !== "var") s = "the quantity " + s + END;
    return s;
  }
  return tidy(rl(ast));
}
function tidy(s) {
  return s.replace(new RegExp(END + "\\s*$"), "")
    .replace(new RegExp(END + "+", "g"), END)
    .replace(new RegExp(END + "\\s*", "g"), ", ")
    .replace(/,\s*,/g, ",").replace(/\s+/g, " ").trim();
}
const OPEN = "\u2039", CLOSE = "\u203A";
function readMeaning(ast) {
  const wrap = (x) => (/ and |, /.test(x) ? OPEN + x + CLOSE : x);
  function negOf(n) { return n.type === "num" ? "negative " + numSay(n) : "the opposite of " + wrap(rm(n)); }
  function rm(n) {
    if (n.type === "num") return numSay(n);
    if (n.type === "var") return n.name;
    if (n.type === "neg") return negOf(n.arg);
    if (n.op === "+" || n.op === "-") {
      const ts = flatSum({ ...n, paren: 0 });
      if (ts.length === 2 && ts[1].sign < 0) return `the difference of ${wrap(rm(ts[0].node))} and ${wrap(rm(ts[1].node))}`;
      return "the sum of " + listSay(ts.map((t) => wrap(t.sign < 0 ? negOf(t.node) : rm(t.node))));
    }
    if (n.op === "*") {
      const fs = flatMul({ ...n, paren: 0 });
      if (fs.length === 2 && isCoefLike(fs[0]) && isVarPow(fs[1])) return `${rm(fs[0])} times ${rm(fs[1])}`;
      return "the product of " + listSay(fs.map((f) => wrap(rm(f))));
    }
    if (n.op === "/") {
      if (isNumNode(n.right, 2)) return "half of " + wrap(rm(n.left));
      return `${wrap(rm(n.left))} divided by ${wrap(rm(n.right))}`;
    }
    if (n.op === "^") {
      const b = wrap(rm(n.left));
      if (isNumNode(n.right, 2)) return "the square of " + b;
      if (isNumNode(n.right, 3)) return "the cube of " + b;
      if (n.right.type === "num" && n.right.value.isInt && n.right.value.n > 3) return `${b} to the ${ordinal(n.right.value.n)} power`;
      return `${b} to the power of ${wrap(rm(n.right))}`;
    }
    return "";
  }
  return rm(ast).replace(/\s+/g, " ").trim();
}
function meaningPlain(s) {
  return s.replace(new RegExp(CLOSE + "+(?=\\s*$)"), "").replace(new RegExp(CLOSE + "+(?=,)", "g"), "")
    .replace(new RegExp(CLOSE + "+", "g"), ",").replace(new RegExp(OPEN, "g"), "").replace(/,\s*,/g, ",").replace(/\s+/g, " ").trim();
}
function meaningHTML(s) {
  return esc(s).replace(new RegExp(OPEN, "g"), '<span class="grp">').replace(new RegExp(CLOSE, "g"), "</span>");
}

/* ---------- Plain unicode text of a chunk/node (for tree labels) ---------- */
function plainText(n, parent = null, side = null) {
  let s;
  switch (n.type) {
    case "num": s = n.text !== undefined ? (n.sup ? n.text : n.text) : frText(n.value, false); break;
    case "var": s = n.name; break;
    case "neg": s = MINUS + plainText(n.arg, n, "arg"); break;
    case "bin":
      if (n.op === "^") {
        const e = n.right;
        s = plainText(n.left, n, "left") + (e.type === "num" && e.value.isInt ? supStr(e.value.n) : "^" + plainText(e, n, "right"));
      } else if (n.op === "/") s = plainText(n.left, n, "left") + "/" + plainText(n.right, n, "right");
      else if (n.op === "*") {
        const clash = startsWithDigit(n.right);
        s = plainText(n.left, n, "left") + (n.implicit && !clash ? "" : " × ") + plainText(n.right, n, "right");
      } else s = plainText(n.left, n, "left") + (n.op === "+" ? " + " : ` ${MINUS} `) + plainText(n.right, n, "right");
  }
  const show = (n.paren && !(parent && parent.op === "/")) || (!n.paren && needsParen(n, parent, side)) || (parent && parent.op === "/" && precOf(n) < 9);
  return show ? "(" + s + ")" : s;
}

/* ---------- Structure tree ---------- */
function treeOf(n, chunk = true) {
  if (chunk && isChunk(n) && n.type !== "num" && n.type !== "var") return { label: plainText({ ...n, paren: 0 }), leaf: true, kind: "chunk" };
  if (n.type === "num") return { label: n.text !== undefined ? n.text : frText(n.value, false), leaf: true, kind: "num" };
  if (n.type === "var") return { label: n.name, leaf: true, kind: "var" };
  if (n.type === "neg") return { label: MINUS, name: "opposite", kids: [treeOf(n.arg)], paren: n.paren };
  const names = { "+": "add", "-": "subtract", "*": "multiply", "/": "divide", "^": "power" };
  const sym = { "+": "+", "-": MINUS, "*": "×", "/": "÷", "^": "^" }[n.op];
  return { label: sym, name: names[n.op], kids: [treeOf(n.left), treeOf(n.right)], paren: n.paren };
}
function layoutTree(root) {
  let x = 0, maxD = 0;
  const nodes = [], edges = [];
  function w(t) { return t.leaf ? Math.max(46, t.label.length * 13 + 22) : 44; }
  function rec(t, d) {
    maxD = Math.max(maxD, d);
    if (t.leaf) { const ww = w(t); t.x = x + ww / 2; t.w = ww; x += ww + 14; }
    else { t.kids.forEach((k) => rec(k, d + 1)); t.x = (t.kids[0].x + t.kids[t.kids.length - 1].x) / 2; t.w = 44; t.kids.forEach((k) => edges.push([t, k])); }
    t.d = d; nodes.push(t);
  }
  rec(root, 0);
  return { nodes, edges, width: Math.max(x - 14, 60), depth: maxD };
}

/* ---------- Main operation (Scan) ---------- */
function mainOperation(ast) {
  const ts = topTerms(ast);
  if (ts.length > 1) {
    const hasMinus = ts.some((t) => t.sign < 0);
    return { kind: "sum", terms: ts.length, title: `${ts.length} terms`, text: `The last step is ${hasMinus ? "adding and subtracting" : "adding"}, so this expression is a sum of ${ts.length} terms.` };
  }
  const n = ast;
  if (n.type === "num") return { kind: "const", terms: 1, title: "1 term", text: "This is a single number: a constant." };
  if (n.type === "var") return { kind: "var", terms: 1, title: "1 term", text: "This is a single variable." };
  if (n.type === "neg") return { kind: "neg", terms: 1, title: "1 term", text: "The last step is taking the opposite, so this is one term with a negative sign in front." };
  if (n.op === "*") {
    if (isChunk(n)) return { kind: "mono", terms: 1, title: "1 term", text: "This is one term (a monomial): a number multiplied by variables." };
    return { kind: "product", terms: 1, title: "1 term", text: "The last step is multiplying, so this whole expression is a product: one term made of factors." };
  }
  if (n.op === "/") return { kind: "quot", terms: 1, title: "1 term", text: "The last step is dividing, so this expression is a quotient (a fraction)." };
  if (n.op === "^") return { kind: "power", terms: 1, title: "1 term", text: "The last step is raising to a power, so this expression is a power." };
  return { kind: "?", terms: 1, title: "1 term", text: "" };
}

/* ---------- Terms (Split) ---------- */
function analyzeTerms(parsed) {
  const ts = topTerms(parsed.ast);
  const infos = ts.map((t, i) => {
    const signed = t.sign < 0 ? { type: "neg", arg: t.node } : t.node;
    const p = polyOf(signed);
    const info = { i, sign: t.sign, node: t.node, opTok: t.opTok, poly: p };
    info.text = (t.sign < 0 ? MINUS : (i === 0 ? "" : "+")) + plainText({ ...t.node, paren: t.node.paren }, null, null);
    if (p && p.size <= 1) {
      const m = p.size ? [...p.values()][0] : { c: new Fr(0), e: {} };
      info.mono = m; info.key = monoKey(m.e); info.degree = Poly.degree(m.e);
      info.varPart = varPart(m.e, false);
      info.simple = isChunk(t.node);
    } else if (p) info.expands = p;
    return info;
  });
  const fam = new Map();
  infos.forEach((t) => { if (t.mono && !t.mono.c.zero) { if (!fam.has(t.key)) fam.set(t.key, []); fam.get(t.key).push(t.i); } });
  let letter = 0;
  for (const [k, arr] of fam) if (arr.length > 1) { const L = "ABCDEFG"[letter++]; arr.forEach((i) => { infos[i].likeGroup = L; infos[i].likeKey = k; }); }
  return infos;
}

/* ---------- Substitution steps (Substitute) ---------- */
function substitute(n, env) {
  if (n.type === "var") return { type: "num", value: env[n.name], sub: true, paren: 0 };
  if (n.type === "num") return { ...n };
  if (n.type === "neg") {
    if (n.arg.type === "num" && !n.arg.sub && !n.arg.paren && !n.paren && n.arg.text !== undefined)
      return { type: "num", value: n.arg.value.neg(), text: MINUS + n.arg.text, paren: 0 };
    return { ...n, arg: substitute(n.arg, env) };
  }
  return { ...n, left: substitute(n.left, env), right: substitute(n.right, env) };
}
function visible(h) { return h.replace(/<[^>]+>/g, ""); }
function substitutionSteps(ast, env) {
  let t = substitute(ast, env);
  const out = [renderHTML(t)];
  for (let guard = 0; guard < 80 && t.type !== "num"; guard++) {
    const ready = [];
    (function collect(n, depth) {
      const d = depth + (n.paren ? 1 : 0);
      if (n.type === "neg") { if (n.arg.type === "num") ready.push({ n, prio: d * 10 + 2 }); else collect(n.arg, d); return; }
      if (n.type !== "bin") return;
      if (n.left.type === "num" && n.right.type === "num") { ready.push({ n, prio: d * 10 + (n.op === "^" ? 4 : PREC[n.op] === 2 ? 2 : 1) }); return; }
      collect(n.left, d); collect(n.right, d);
    })(t, 0);
    if (!ready.length) break;
    const maxP = Math.max(...ready.map((r) => r.prio));
    const set = new Set(ready.filter((r) => r.prio === maxP).map((r) => r.n));
    t = (function reduce(n) {
      if (set.has(n)) {
        const v = evalNode(n, {});
        return { type: "num", value: v, paren: n.paren && n.paren > 0 && n.type === "bin" && (n.op === "+" || n.op === "-") ? 1 : 0 };
      }
      if (n.type === "neg") return { ...n, arg: reduce(n.arg) };
      if (n.type === "bin") return { ...n, left: reduce(n.left), right: reduce(n.right) };
      return n;
    })(t);
    const s = renderHTML(t);
    if (visible(s) !== visible(out[out.length - 1])) out.push(s);
  }
  if (t.type === "num" && (t.paren || t.sub)) {
    const final = renderHTML({ type: "num", value: t.value });
    if (visible(final) !== visible(out[out.length - 1])) out.push(final);
  }
  return out;
}

/* ---------- Equivalence ---------- */
function equivalent(a, b) {
  const pa = polyOf(a), pb = polyOf(b);
  if (pa && pb) return Poly.equal(pa, pb);
  const vars = [...new Set([...varsIn(a), ...varsIn(b)])];
  const pts = [-3, -2, -1, 1, 2, 3, 5, 7];
  let tested = 0;
  for (let k = 0; k < pts.length; k++) {
    const env = {}; vars.forEach((v, j) => (env[v] = new Fr(pts[(k + j * 3) % pts.length])));
    const x = tryEval(a, env), y = tryEval(b, env);
    if (x && y) { tested++; if (!x.eq(y)) return false; }
  }
  return tested > 0;
}


/* ---------- Everyday reading (Schleppegrell; Moschkovich: everyday talk as a resource) ---------- */
function readEveryday(ast) {
  const word = (k) => ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve"][k] || String(k);
  const vpWord = (e, plural) => {
    const vs = Object.keys(e).sort().map((v) => (e[v] === 1 ? v : e[v] === 2 ? v + "-squared" : e[v] === 3 ? v + "-cubed" : v + " to the " + e[v]));
    const s = vs.join("-");
    return plural ? s + (vs.length === 1 && vs[0].length === 1 ? "'s" : "s") : s;
  };
  function monoWords(m) {
    const vp = Object.keys(m.e).length;
    const c = m.c.abs();
    if (!vp) return c.isInt ? word(c.n) : `${c.n}/${c.d}`;
    if (c.isInt && c.n === 1) return "one " + vpWord(m.e, false);
    if (!c.isInt && c.n === 1 && c.d === 2) return "half an " + vpWord(m.e, false);
    return (c.isInt ? word(c.n) : `${c.n}/${c.d} of an`) + " " + vpWord(m.e, c.isInt);
  }
  function termWords(node, sign) {
    if (isBin(node, "*") && isCoefLike(node.left) && node.right.paren && (node.right.op === "+" || node.right.op === "-")) {
      const k = evalNode(node.left, {});
      if (k.isInt && Math.abs(k.n) > 1) return { neg: (k.n < 0) !== (sign < 0), text: `${word(Math.abs(k.n))} groups of (${readEveryday({ ...node.right, paren: 0 })})` };
    }
    const p = polyOf(sign < 0 ? { type: "neg", arg: node } : node);
    if (p && p.size === 1 && isChunk(node)) { const [m] = p.values(); if (Object.values(m.e).every((x) => x > 0)) return { neg: m.c.negative, text: monoWords(m) }; }
    if (p && p.size === 0) return { neg: false, text: "zero" };
    return { neg: sign < 0, text: readLiteral(node) };
  }
  const ts = topTerms(ast);
  return ts.map((t, i) => {
    const w = termWords(t.node, t.sign);
    if (i === 0) return (w.neg ? "negative " : "") + w.text;
    return (w.neg ? "take away " : "add ") + w.text;
  }).join(", ");
}

/* ---------- Ambiguity check (MacGregor & Price; MacGregor & Stacey) ----------
   Read the expression aloud without "the quantity": what would a listener write? */
function textNoBrackets(n) {
  switch (n.type) {
    case "num": return n.text !== undefined ? n.text : String(n.value);
    case "var": return n.name;
    case "neg": return "-" + textNoBrackets(n.arg);
    case "bin": {
      const L = textNoBrackets(n.left), R = textNoBrackets(n.right);
      if (n.op === "^") return L + "^" + (n.right.type === "num" ? R : "(" + R + ")");
      if (n.op === "*") return n.implicit && !/^[0-9.\-]/.test(R) ? L + R : L + "*" + R;
      return L + n.op + R;
    }
  }
}
function hasGroupBrackets(n) {
  if (n.paren && n.type !== "num" && n.type !== "var") return true;
  if (n.type === "neg") return hasGroupBrackets(n.arg);
  if (n.type === "bin") return hasGroupBrackets(n.left) || hasGroupBrackets(n.right);
  return false;
}
function ambiguityCheck(parsed) {
  if (!hasGroupBrackets(parsed.ast)) return null;
  try {
    const alt = parse(textNoBrackets(parsed.ast));
    if (equivalent(alt.ast, parsed.ast)) return null;
    return alt;
  } catch (e) { return null; }
}

/* ---------- Squint view (Hoch & Dreyfus: see a sub-expression as one object) ---------- */
function squint(ast) {
  const legend = new Map();
  const L = "ABCDEFGH";
  function rec(n) {
    if (n.paren && n.type !== "num" && n.type !== "var") {
      const key = plainText({ ...n, paren: 0 });
      if (!legend.has(key)) legend.set(key, { letter: L[legend.size] || "?", node: n, count: 0 });
      const g = legend.get(key); g.count++;
      return { type: "var", name: g.letter, box: true, paren: 0 };
    }
    if (n.type === "neg") return { ...n, arg: rec(n.arg) };
    if (n.type === "bin") return { ...n, left: rec(n.left), right: rec(n.right) };
    return n;
  }
  const tree = rec(ast);
  return legend.size ? { tree, legend: [...legend.entries()].map(([k, g]) => ({ text: k, letter: g.letter, count: g.count })) } : null;
}

/* ---------- Principal operation (Kirshner & Awtry's Lexical Support System) ---------- */
function principal(ast) {
  const ts = topTerms(ast);
  const txt = (n) => plainText({ ...n, paren: n.paren });
  if (ts.length > 1) return { op: ts.some((t) => t.sign < 0) ? "addition and subtraction" : "addition", subs: ts.map((t, i) => (t.sign < 0 ? MINUS : i ? "+" : "") + txt(t.node)), subName: "terms" };
  const n = ast;
  if (n.type === "num" || n.type === "var") return { op: "none (a single number or letter)", subs: [], subName: "" };
  if (n.type === "neg") return { op: "taking the opposite", subs: [txt(n.arg)], subName: "subexpression" };
  if (n.op === "*") return { op: "multiplication", subs: flatMul({ ...n, paren: 0 }).map(txt), subName: "factors" };
  if (n.op === "/") return { op: "division", subs: [txt(n.left), txt(n.right)], subName: "numerator and denominator" };
  return { op: "raising to a power", subs: [txt(n.left), txt(n.right)], subName: "base and exponent" };
}

const Engine = {
  MINUS, Fr, MathError, parse, tokenize, topTerms, flatSum, flatMul, containsVar, varsIn, isChunk, isCoefLike, isVarPow,
  ROLE_NAMES, Poly, polyOf, polyText, monoText, varPart, supStr, frText, evalNode, tryEval,
  renderHTML, plainText, readLiteral, readMeaning, meaningPlain, meaningHTML, esc, treeOf, layoutTree, mainOperation, analyzeTerms,
  substitutionSteps, equivalent, readEveryday, ambiguityCheck, squint, principal, textNoBrackets,
};
if (typeof module !== "undefined") module.exports = Engine;
