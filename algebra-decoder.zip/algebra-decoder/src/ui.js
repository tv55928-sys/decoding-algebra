"use strict";
/* ============================================================
   Algebra Decoder UI
   ============================================================ */
const E = Engine;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const M = E.MINUS;
const ROLE_ORDER = ["var", "coef", "const", "exp", "op", "group"];
const ROLE_LABEL = { var: "variable", coef: "coefficient", const: "constant", exp: "exponent", op: "operation", group: "bracket" };
const ROLE_PLURAL = { var: "Variables", coef: "Coefficients", const: "Constants", exp: "Exponents", op: "Operations", group: "Brackets" };
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const shuffle = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const rint = (lo, hi) => lo + Math.floor(Math.random() * (hi - lo + 1));
const SPEAK_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>';
const canSpeak = (() => { try { return "speechSynthesis" in window && typeof SpeechSynthesisUtterance !== "undefined"; } catch (e) { return false; } })();
function speak(text) {
  try { window.speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text.replace(/−/g, "minus ")); u.rate = 0.88; window.speechSynthesis.speak(u); } catch (e) { /* speech not available */ }
}
function speakBtn(text, label) {
  return canSpeak ? `<button class="speak" type="button" data-speak="${E.esc(text).replace(/"/g, "&quot;")}" aria-label="${label}">${SPEAK_ICON}</button>` : "";
}
document.addEventListener("click", (e) => { const b = e.target.closest("[data-speak]"); if (b) speak(b.dataset.speak); });


/* ============================================================
   Research base: what each source found and what the app does with it
   ============================================================ */
const REFS = {
  schleppegrell: { short: "Schleppegrell, 2007", group: "Language and literacy", apa: "Schleppegrell, M. J. (2007). The linguistic challenges of mathematics teaching and learning: A research review. <i>Reading & Writing Quarterly, 23</i>(2), 139–159.", link: "https://doi.org/10.1080/10573560601158461", access: "Abstract and published summaries",
    found: "A review of research by linguists and math educators. Math talk mixes symbols, speech, writing and graphs, and has its own grammar: technical words, long noun phrases that pack in a lot of meaning, and small linking words with exact meanings. Teachers help students move from everyday talk toward this more precise register.",
    app: "Say gives three readings that move from everyday talk to math meaning. The first noun of the math reading (sum, product, square) names the last operation." },
  shanahan: { short: "Shanahan & Shanahan, 2008", group: "Language and literacy", apa: "Shanahan, T., & Shanahan, C. (2008). Teaching disciplinary literacy to adolescents: Rethinking content-area literacy. <i>Harvard Educational Review, 78</i>(1), 40–59.", link: "https://doi.org/10.17763/haer.78.1.v62444321p602101", access: "Full text",
    found: "Compared how experts in math, chemistry and history read. The mathematicians stressed rereading and close reading, precision down to small words, and reading to check for errors. They noted that letters can play different roles, and that math meanings of words have to be learned separately from everyday meanings.",
    app: "Read like a mathematician (on The 6 S's). The Word bank sets everyday meanings beside math meanings. Find the error builds the habit of reading to check." },
  moschkovich: { short: "Moschkovich, 2015", group: "Language and literacy", apa: "Moschkovich, J. N. (2015). Academic literacy in mathematics for English Learners. <i>Journal of Mathematical Behavior, 40</i>, 43–62.", link: "https://doi.org/10.1016/j.jmathb.2015.01.005", access: "Full text",
    found: "Defines academic literacy in math as three parts taught together: mathematical proficiency, mathematical practices, and mathematical discourse. Treating math language as a vocabulary list cuts it off from reasoning. Everyday language, home languages, gestures, drawings, tables and graphs are resources, and precision is mostly about stating when a claim is true.",
    app: "Everyday talk counts as a starting reading. Talk prompts and sentence starters invite explanation. Every expression is shown several ways, and Same or different? asks whether a claim holds for every value." },
  riccomini: { short: "Riccomini et al., 2015", group: "Language and literacy", apa: "Riccomini, P. J., Smith, G. W., Hughes, E. M., & Fries, K. M. (2015). The language of mathematics: The importance of teaching and learning mathematical vocabulary. <i>Reading & Writing Quarterly, 31</i>(3), 235–252.", link: "https://doi.org/10.1080/10573569.2015.1030995", access: "Full text",
    found: "Argues that vocabulary is central to mathematical proficiency. Building on Rubenstein and Thompson, it lists ways math words trip students up, such as math meanings that are more precise than everyday ones (product) and informal terms used in place of formal ones. It recommends explicit teaching, many exposures, restating terms in your own words, and game-like practice such as word sorts.",
    app: "Word bank cards show the everyday and math meaning, an example and a non-example, and a prompt to say it in your own words. Word check is a quick sorting game." },
  rubenstein: { short: "Rubenstein & Thompson, 2001", group: "Symbols and notation", apa: "Rubenstein, R. N., & Thompson, D. R. (2001). Learning mathematical symbolism: Challenges and instructional strategies. <i>Mathematics Teacher, 94</i>(4), 265–271.", link: "", access: "Abstract and opening section",
    found: "Describes how symbols are used and the trouble students have saying, reading and writing them. Saying a symbol aloud works at the surface; understanding it reaches its meaning. Some symbols can be said in several ways, and errors such as getting −3 for −x when x = −3 show how meaning slips.",
    app: "Every expression has several readings. The − sign is labelled as subtract, negative or opposite. Find the error includes −x² with a negative value." },
  macgregorPrice: { short: "MacGregor & Price, 1999", group: "Symbols and notation", apa: "MacGregor, M., & Price, E. (1999). An exploration of aspects of language proficiency and algebra learning. <i>Journal for Research in Mathematics Education, 30</i>(4).", link: "https://www.nctm.org/Publications/journal-for-research-in-mathematics-education/1999/Vol30/Issue4/An-Exploration-of-Aspects-of-Language-Proficiency-and-Algebra-Learning/", access: "Abstract",
    found: "Tested more than 1,500 students aged 11 to 15 on awareness of symbols, syntax and ambiguity in language. Very few students with low awareness scores reached high algebra scores.",
    app: "The ambiguity alert in Say shows what a listener could write if “the quantity” is left out. Write it targets word order, and Find the error targets what a letter stands for." },
  macgregorStacey: { short: "MacGregor & Stacey, 1997", group: "Symbols and notation", apa: "MacGregor, M., & Stacey, K. (1997). Students' understanding of algebraic notation: 11–15. <i>Educational Studies in Mathematics, 33</i>, 1–19.", link: "https://doi.org/10.1023/A:1002970913563", access: "Full text",
    found: "Tested about 2,000 students in Years 7–10. Errors came from sensible guesses about unfamiliar notation, borrowing from other symbol systems (reading h as 8 because it is the 8th letter), interference from newly taught rules (writing x³ for 3x rose from 5% in Year 7 to 18% in Year 10), and materials that treat letters as short forms of words. At one school, explicit lessons on grouping, brackets and ambiguity raised success from 31% to 81%.",
    app: "Find the error items on letter meanings and on x³ versus 3x. The ambiguity alert and the bracket colour make grouping visible." },
  arcavi: { short: "Arcavi, 1994", group: "Seeing structure", apa: "Arcavi, A. (1994). Symbol sense: Informal sense-making in formal mathematics. <i>For the Learning of Mathematics, 14</i>(3), 24–35.", link: "https://flm-journal.org/Articles/BFBFB3A8A2A03CF606513A05A22B", access: "Full text",
    found: "Describes symbol sense through eight behaviours. They include knowing when to use symbols, pausing a calculation to read meaning through the symbols, checking by substituting, finding new meaning in equivalent forms, and recognizing the different roles a letter can play.",
    app: "Substitute asks for a prediction before showing the work. The Simplified view treats an equivalent form as new information." },
  hoch: { short: "Hoch & Dreyfus, 2004", group: "Seeing structure", apa: "Hoch, M., & Dreyfus, T. (2004). Structure sense in high school algebra: The effect of brackets. In M. J. Høines & A. B. Fuglestad (Eds.), <i>Proceedings of PME 28</i> (Vol. 3, pp. 49–56).", link: "https://emis.univie.ac.at/proceedings/PME28/RR/RR025_Hoch.pdf", access: "Full text",
    found: "Defines structure sense: seeing an expression as one object, recognizing a familiar structure, splitting it into parts, and seeing which steps are possible and useful. With 92 Grade 11 students, structure sense rose with brackets (6.3% with none, 13.6% with one set, 17.7% with two) but stayed rare. The authors suggest teaching students to look before they do.",
    app: "The squint view turns each bracket group into one box. Scan comes before any calculating." },
  landy: { short: "Landy & Goldstone, 2007", group: "Seeing structure", apa: "Landy, D., & Goldstone, R. L. (2007). How abstract is symbolic thought? <i>Journal of Experimental Psychology: Learning, Memory, and Cognition, 33</i>(4), 720–733.", link: "https://doi.org/10.1037/0278-7393.33.4.720", access: "Full text",
    found: "Four experiments varied visual grouping cues that have no mathematical meaning, such as spacing and enclosing shapes. Adults judged equations more accurately when the cues matched the order of operations and less accurately when they clashed. For spacing, the gap was about 39 percentage points on items where the order mattered, and it persisted even with feedback.",
    app: "Expressions are set with tight spacing for multiplication and wider spacing around + and −. Find the error includes an item with misleading spacing." },
  kirshner: { short: "Kirshner & Awtry, 2004", group: "Seeing structure", apa: "Kirshner, D., & Awtry, T. (2004). Visual salience of algebraic transformations. <i>Journal for Research in Mathematics Education, 35</i>(4), 224–257.", link: "https://doi.org/10.2307/30034809", access: "Full text",
    found: "Grade 7 students recognized rules that look visually neat, like 2(x − y) = 2x − 2y, far more readily than other rules (73% vs 40%), and found it harder to reject false look-alikes such as (x + y)² = x² + y². The authors propose a Lexical Support System that describes structure in words: principal operation, terms, factors.",
    app: "Scan names the principal operation and its parts. Find the error states each rule in words. Same or different? includes look-alike pairs." },
  duval: { short: "Duval, 2006", group: "Representations and instruction", apa: "Duval, R. (2006). A cognitive analysis of problems of comprehension in a learning of mathematics. <i>Educational Studies in Mathematics, 61</i>, 103–131.", link: "https://doi.org/10.1007/s10649-006-0400-z", access: "Abstract and published summaries",
    found: "Separates two kinds of work: treatments (changing a representation within one system, like simplifying) and conversions (changing systems, like symbols to a graph). Conversion is the deciding factor for learning. It is often harder than it looks, and going one way is a different task from going back.",
    app: "Show converts each expression to tiles, a table, a graph and words. Practice runs conversions both ways: Match the tiles and Build it, Say it right and Write it." },
  witzel: { short: "Witzel et al., 2003", group: "Representations and instruction", apa: "Witzel, B. S., Mercer, C. D., & Miller, M. D. (2003). Teaching algebra to students with learning difficulties: An investigation of an explicit instruction model. <i>Learning Disabilities Research & Practice, 18</i>(2), 121–131.", link: "https://doi.org/10.1111/1540-5826.00068", access: "Abstract",
    found: "Compared explicit concrete–representational–abstract (CRA) instruction with traditional instruction for 34 matched pairs of Grade 6 and 7 students with, or at risk for, learning disabilities. Students taught with CRA made fewer procedural errors when solving for variables.",
    app: "Build it uses virtual tiles, and Show orders the forms Build, Draw, Write. Teacher notes suggest physical tiles first." },
  star: { short: "Star et al., 2015", group: "Representations and instruction", apa: "Star, J. R., Caronongan, P., Foegen, A., Furgeson, J., Keating, B., Larson, M. R., Lyskawa, J., McCallum, W. G., Porath, J., & Zbiek, R. M. (2015). <i>Teaching strategies for improving algebra knowledge in middle and high school students</i> (NCEE 2015-4010). Institute of Education Sciences.", link: "https://ies.ed.gov/ncee/wwc/practiceguide/20", access: "Guide summary and companion materials",
    found: "Three recommendations: (1) analyze solved problems, including clearly labelled incorrect ones placed beside correct ones; (2) teach students to use structure through precise language (say “add to zero”, not “cancel”), reflective questions and multiple representations; (3) teach students to choose among strategies. Evidence ratings: minimal, minimal, moderate.",
    app: "Find the error; Ask yourself questions in Scan; precise wording throughout (zero pairs add to zero); Same or different? names three strategies." },
  booth: { short: "Booth et al., 2013", group: "Representations and instruction", apa: "Booth, J. L., Lange, K. E., Koedinger, K. R., & Newton, K. J. (2013). Using example problems to improve student learning in algebra: Differentiating between correct and incorrect examples. <i>Learning and Instruction, 25</i>, 24–34.", link: "", access: "Abstract",
    found: "Two classroom experiments with the Algebra I Cognitive Tutor added correct and incorrect worked examples with prompts to explain them. Incorrect examples, alone or mixed with correct ones, appeared especially helpful for conceptual understanding.",
    app: "Find the error: spot the wrong line, choose why it is wrong, then compare with correct work." },
};
function cite(...ids) { return ids.map((id) => `<a class="cite" href="#research" data-cite="${id}">${REFS[id].short}</a>`).join("; "); }
function why(text, ...ids) { return `<details class="why"><summary>Why this step?</summary><p>${text} <span class="refs">(${cite(...ids)})</span></p></details>`; }
document.addEventListener("click", (e) => {
  const a = e.target.closest("[data-cite]"); if (!a) return;
  e.preventDefault(); if (document.body.classList.contains("student-mode")) return; go("research");
  const card = document.getElementById("ref-" + a.dataset.cite);
  if (card) { card.scrollIntoView({ block: "center" }); card.classList.add("flash"); setTimeout(() => card.classList.remove("flash"), 1600); }
});

function tryParse(src) { try { return { p: E.parse(src) }; } catch (e) { return { err: e.friendly ? e.message : "I couldn't read that expression." }; } }
function exprHTML(parsed, opts = {}) { return E.renderHTML(parsed.ast, { roles: parsed.toks, ...opts }); }
function polyHTML(p) { return E.polyText(p, true); }
function decorate(el, { labels = true, animate = false, parsed = null } = {}) {
  let k = 0, i = 0;
  $$(".tk", el).forEach((t) => {
    if (animate) t.style.setProperty("--i", i++);
    const r = t.dataset.role;
    if (!r || !labels) return;
    if (t.closest("sup") || t.classList.contains("caret") || t.classList.contains("bar") || r === "group") return;
    if (r === "op" || (t.classList.contains("sign") && r !== "op")) {
      const tok = parsed && parsed.toks[+t.dataset.tok];
      if (r !== "op" || !tok || tok.t !== "-" || !tok.meaning) return;
      t.dataset.label = tok.meaning; t.dataset.row = k++ % 2; return;
    }
    t.dataset.label = ROLE_LABEL[r];
    t.dataset.row = k++ % 2;
  });
}
function termSetOf(parsed) { const ts = E.topTerms(parsed.ast); const m = new Map(); ts.forEach((t, i) => m.set(t.node, i)); return m; }
function singleVar(parsed) { const v = [...E.varsIn(parsed.ast)]; return v.length === 1 ? v[0] : null; }
function evalFloat(n, x, v) {
  switch (n.type) {
    case "num": return n.value.valueOf();
    case "var": return n.name === v ? x : NaN;
    case "neg": return -evalFloat(n.arg, x, v);
    default: {
      const a = evalFloat(n.left, x, v), b = evalFloat(n.right, x, v);
      return n.op === "+" ? a + b : n.op === "-" ? a - b : n.op === "*" ? a * b : n.op === "/" ? a / b : Math.pow(a, b);
    }
  }
}
function fmtFr(fr) { return fr ? E.frText(fr, true) : "—"; }

/* ============================================================
   Panel builders (shared by Decode and the 6 S walk-through)
   ============================================================ */
function scanHTML(parsed) {
  const mo = E.mainOperation(parsed.ast);
  const pr = E.principal(parsed.ast);
  const root = E.treeOf(parsed.ast, !E.isChunk(parsed.ast) || parsed.ast.type === "num" || parsed.ast.type === "var");
  const L = E.layoutTree(root);
  const W = L.width + 16, H = (L.depth + 1) * 66 + 10;
  const y = (d) => 30 + d * 66;
  let svg = `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="Expression tree. Principal operation: ${pr.op}">`;
  L.edges.forEach(([a, b]) => { svg += `<line class="tree-edge" x1="${a.x + 8}" y1="${y(a.d)}" x2="${b.x + 8}" y2="${y(b.d)}"/>`; });
  L.nodes.forEach((t) => {
    const cx = t.x + 8, cy = y(t.d);
    if (t.leaf) svg += `<rect class="tree-leaf" x="${cx - t.w / 2}" y="${cy - 17}" width="${t.w}" height="34" rx="8"/><text class="tree-text" x="${cx}" y="${cy}">${E.esc(t.label)}</text>`;
    else svg += `<circle class="tree-op${t === root ? " root" : ""}" cx="${cx}" cy="${cy}" r="19"/><text class="tree-text op${t === root ? " tree-root-text" : ""}" x="${cx}" y="${cy}">${E.esc(t.label)}</text>`;
  });
  svg += "</svg>";
  const plusMinus = E.topTerms(parsed.ast).length - 1;
  const sq = E.squint(parsed.ast);
  const vars = [...E.varsIn(parsed.ast)].sort();
  let html = `<p class="say">${plusMinus > 0 ? `I can see <b>${plusMinus}</b> + or ${M} sign${plusMinus > 1 ? "s" : ""} outside brackets.` : "There are no + or " + M + " signs outside brackets."} ${mo.text}</p>
    <p class="lss">Principal operation: <b>${pr.op}</b>${pr.subs.length ? `<br>Its ${pr.subName}: ${pr.subs.map((s) => `<span class="subchip math">${E.esc(s)}</span>`).join(" ")}` : ""}</p>`;
  if (sq) {
    const rep = sq.legend.filter((g) => g.count > 1);
    html += `<div class="squint"><p class="note"><b>Squint:</b> treat each bracket group as one box.</p><p class="squintexpr math">${E.renderHTML(sq.tree)}</p>
      <p class="note">${sq.legend.map((g) => `<span class="chunkbox small">${g.letter}</span> = (${E.esc(g.text)})${g.count > 1 ? `, appears ${g.count} times` : ""}`).join(" · ")}</p>
      ${rep.length ? `<p class="callout">The same group appears more than once. Seeing it as one object can save work.</p>` : ""}</div>`;
  }
  html += `<div class="treebox">${svg}</div>
    <p class="note">Read the tree from the bottom up. Each circle is an operation done to the parts under it. The highlighted circle is the principal operation, done last.</p>
    <details class="ask" open><summary>Ask yourself</summary><ul>
      <li><b>What kind of expression is this?</b> <span class="ans">${pr.op === "addition and subtraction" || pr.op === "addition" ? "a sum of terms" : "one term whose principal operation is " + pr.op}</span></li>
      <li><b>How many terms and variables?</b> <span class="ans">${E.topTerms(parsed.ast).length} term${E.topTerms(parsed.ast).length > 1 ? "s" : ""}; ${vars.length ? vars.length + " variable" + (vars.length > 1 ? "s" : "") + " (" + vars.join(", ") + ")" : "no variables"}</span></li>
      <li><b>Have I seen this structure before?</b> <span class="ans">${sq && sq.legend.some((g) => g.count > 1) ? "yes, a bracket group repeats" : "compare it with the examples above"}</span></li>
    </ul></details>
    ${why("Look before you do. Naming the principal operation in words, and seeing a bracket group as one object, helps you read structure instead of reacting to how the symbols look.", "hoch", "kirshner", "star")}`;
  return html;
}

function splitHTML(parsed) {
  const ts = E.analyzeTerms(parsed);
  const chips = ts.map((t) => `<span class="termchip${t.likeGroup ? " like-" + t.likeGroup : ""}">${E.esc(t.text)}${t.likeGroup ? `<span class="tag">like ${t.likeGroup}</span>` : ""}</span>`).join("");
  const names = ["", "monomial", "binomial", "trinomial"];
  const kind = ts.length <= 3 ? `a <b>${names[ts.length]}</b>` : "a <b>polynomial</b>";
  let html = `<p class="say"><b>${ts.length}</b> term${ts.length > 1 ? "s" : ""}, so it is written as ${kind}.</p><div class="termrow">${chips}</div>`;
  const like = new Map(); ts.forEach((t) => { if (t.likeGroup) { if (!like.has(t.likeGroup)) like.set(t.likeGroup, []); like.get(t.likeGroup).push(t); } });
  if (like.size) {
    const parts = [...like.entries()].map(([g, arr]) => `${arr.map((t) => `<span class="math">${E.esc(t.text.replace(/^\+/, ""))}</span>`).join(" and ")} are like terms (same variable part <span class="math">${arr[0].varPart || "constant"}</span>)`);
    html += `<p class="callout">${parts.join("; ")}. Like terms can be combined.</p>`;
  }
  if (ts.some((t) => t.expands)) html += `<p class="note">A term with brackets stays one term until you expand it. The brackets keep its parts together.</p>`;
  html += `<p class="note">The sign in front of a term belongs to that term.</p>`;
  html += why("Seeing where each term starts and ends is part of structure sense. Brackets help: a bracket group stays inside one term.", "hoch", "star");
  return html;
}

function spotHTML(parsed) {
  const ts = E.analyzeTerms(parsed);
  const rows = ts.map((t) => {
    const term = `<td class="math">${E.esc(t.text.replace(/^\+/, ""))}</td>`;
    if (t.mono) {
      const vp = t.varPart;
      const exps = Object.entries(t.mono.e).map(([v, k]) => `${v}: ${k < 0 ? M + Math.abs(k) : k}`).join(", ");
      const deg = Object.values(t.mono.e).every((k) => k >= 0) ? t.degree : "—";
      const coefCell = vp ? fmtFr(t.mono.c) : "—";
      const what = !vp ? "constant term" : `${vp}-term`;
      const extra = t.simple ? "" : `<br><span class="note">simplifies to <span class="math">${E.monoText(t.mono, true)}</span></span>`;
      return `<tr>${term}<td class="math">${coefCell}</td><td class="math">${vp ? [...new Set(Object.keys(t.mono.e))].join(", ") : "—"}</td><td>${exps || "—"}</td><td>${deg}</td><td>${what}${extra}</td></tr>`;
    }
    if (t.expands) return `<tr>${term}<td colspan="4" class="note">a product with brackets</td><td>expands to <span class="math">${polyHTML(t.expands)}</span></td></tr>`;
    return `<tr>${term}<td colspan="5" class="note">this term can't be written as a polynomial</td></tr>`;
  }).join("");
  const counts = {}; parsed.toks.forEach((t) => (counts[t.role] = (counts[t.role] || 0) + 1));
  const found = ROLE_ORDER.filter((r) => counts[r]).map((r) => {
    const vals = [...new Set(parsed.toks.filter((t) => t.role === r).map((t) => (t.k === "op" && t.t === "-" ? M : t.k === "op" && t.t === "*" ? "×" : t.k === "op" && t.t === "^" ? "^" : t.k === "sup" ? t.t : t.raw)))].filter((s) => s !== "^");
    return `<b style="color:var(--r-${r})">${ROLE_PLURAL[r]}:</b> <span class="math">${vals.join("  ")}</span>`;
  }).join(" · ");
  const minus = parsed.toks.filter((t) => t.k === "op" && t.t === "-" && t.meaning);
  const mm = {}; minus.forEach((t) => (mm[t.meaning] = (mm[t.meaning] || 0) + 1));
  const mText = { subtract: "subtract (between two parts)", negative: "negative (part of a number)", opposite: "opposite (of a bracket or power)" };
  const minusNote = minus.length ? `<p class="callout">The ${M} sign means different things. Here it means: ${Object.entries(mm).map(([k, n]) => `<b>${mText[k]}</b>${n > 1 ? " ×" + n : ""}`).join(", ")}. Turn on <b>Label the parts</b> to see which is which.</p>` : "";
  return `<div class="tablewrap"><table class="parts"><thead><tr><th>Term</th><th>Coefficient</th><th>Variable</th><th>Exponent</th><th>Degree</th><th>Kind</th></tr></thead><tbody>${rows}</tbody></table></div>
    <p class="note">${found}</p>${minusNote}
    ${why("Naming each part with its math word builds the vocabulary you need to talk about expressions. One symbol can have several meanings, so the − sign is named by its job.", "riccomini", "rubenstein")}`;
}

function headNoun(mean) {
  const m = mean.match(/^(?:the )?(sum|difference|product|square|cube|opposite|half)/);
  if (!m) return "";
  const map = { sum: "addition", difference: "subtraction", product: "multiplication", square: "squaring (a power)", cube: "cubing (a power)", opposite: "taking the opposite", half: "dividing by 2" };
  return `The first noun, <b>“${m[1]}”</b>, names the principal operation: ${map[m[1]]}.`;
}
function sayHTML(parsed) {
  const every = E.readEveryday(parsed.ast);
  const lit = E.readLiteral(parsed.ast);
  const mean = E.readMeaning(parsed.ast);
  const meanPlain = E.meaningPlain(mean);
  const amb = E.ambiguityCheck(parsed);
  return `<div class="reading"><h4>Everyday talk</h4><div class="readline"><p>${E.esc(every)}</p>${speakBtn(every, "Read aloud, everyday talk")}</div></div>
    <div class="reading"><h4>Symbol by symbol</h4><div class="readline"><p>${E.esc(lit)}</p>${speakBtn(lit, "Read aloud, symbol by symbol")}</div></div>
    <div class="reading"><h4>Math meaning</h4><div class="readline"><p>${E.meaningHTML(mean)}</p>${speakBtn(meanPlain, "Read aloud, math meaning")}</div><p class="note">${headNoun(meanPlain)} Underlines show which words belong together.</p></div>
    ${amb ? `<div class="alert"><b>Ambiguity alert.</b> Said aloud without “the quantity”, a listener could write <span class="math colour">${exprHTML(amb)}</span>, which is a different expression. Brackets have to be spoken.</div>` : ""}
    <p class="talk"><b>Talk:</b> Which reading would you use to tell a friend this expression over the phone? Which one tells them what it <i>does</i>?</p>
    ${why("Everyday talk is a fine place to start thinking; the math register is more precise. Reading symbol by symbol works at the surface, while the meaning reading shows structure. Listening for ambiguity is linked to success in algebra.", "schleppegrell", "moschkovich", "rubenstein", "macgregorPrice")}`;
}

/* ---------- Show: tiles / table / graph / simplified ---------- */
function tileable(p, v) {
  if (!p) return false;
  let total = 0;
  for (const [k, t] of p) {
    if (!(k === "" || k === v + "^1" || k === v + "^2")) return false;
    if (!t.c.isInt) return false;
    total += Math.abs(t.c.n);
  }
  return total <= 36;
}
function tilesFor(p, v) {
  const get = (k) => (p.get(k) ? p.get(k).c.n : 0);
  const out = [];
  const make = (cls, n, lab) => { for (let i = 0; i < Math.abs(n); i++) out.push(`<span class="tile ${cls}${n < 0 ? " neg" : ""}" title="${n < 0 ? M : ""}${lab}"><span>${n < 0 ? M : ""}${lab}</span></span>`); };
  make("x2", get(v + "^2"), v + "²"); make("x", get(v + "^1"), v); make("u", get(""), "1");
  return `<div class="tset">${out.join("") || '<span class="note">no tiles (zero)</span>'}</div>`;
}
function tilesHTML(parsed) {
  const v = singleVar(parsed) || "x";
  const whole = E.polyOf(parsed.ast);
  if (!tileable(whole, v) || (whole && whole.size === 0)) {
    return `<p class="note">Algebra tiles work for one variable, whole-number coefficients, and powers up to ${v}². ${whole && whole.size === 0 ? "This expression simplifies to 0." : "Try the table or graph for this one."}</p>`;
  }
  const ts = E.analyzeTerms(parsed);
  let groups = "", ok = true, zeroPair = false;
  const sums = {};
  ts.forEach((t) => {
    const node = t.node;
    if (E.isCoefLike(node.left || {}) && node.type === "bin" && node.op === "*" && node.right.paren) {
      const k = E.evalNode(node.left, {}).n * t.sign;
      const inner = E.polyOf(node.right);
      if (Math.abs(k) >= 2 && Math.abs(k) <= 5 && tileable(inner, v)) {
        const one = k < 0 ? E.polyOf({ type: "neg", arg: node.right }) : inner;
        groups += `<div class="tgroup"><b>${E.esc(t.text.replace(/^\+/, ""))}</b><div class="krow">${Array.from({ length: Math.abs(k) }, () => tilesFor(one, v)).join("")}</div><span class="note">${Math.abs(k)} groups of ${k < 0 ? "the opposite of " : ""}(${E.esc(E.polyText(inner, false))})</span></div>`;
        for (const [key, m] of t.poly) sums[key] = (sums[key] || 0) + Math.abs(m.c.n);
        return;
      }
    }
    if (!tileable(t.poly, v)) { ok = false; return; }
    for (const [key, m] of t.poly) sums[key] = (sums[key] || 0) + Math.abs(m.c.n);
    groups += `<div class="tgroup"><b>${E.esc(t.text.replace(/^\+/, ""))}</b>${tilesFor(t.poly, v)}</div>`;
  });
  for (const key in sums) { const c = whole.get(key) ? Math.abs(whole.get(key).c.n) : 0; if (sums[key] > c) zeroPair = true; }
  const simplified = `<div class="tgroup"><b>${polyHTML(whole)}</b>${tilesFor(whole, v)}</div>`;
  const keyRow = `<p class="note"><span class="tile x2" style="width:14px;height:14px;vertical-align:middle"></span> ${v}² tile · <span class="tile x" style="width:6px;height:14px;vertical-align:middle"></span> ${v} tile · <span class="tile u" style="width:8px;height:8px;vertical-align:middle"></span> 1 tile · red tiles are negative</p>`;
  if (!ok || ts.length === 1 && !groups.includes("groups of")) return `<div class="tiles">${simplified}</div>${keyRow}`;
  return `<p class="say">As written:</p><div class="tiles">${groups}</div>
    <p class="say">After ${zeroPair ? "removing zero pairs and " : ""}combining like terms:</p><div class="tiles">${simplified}</div>
    ${zeroPair ? `<p class="callout">A positive tile and a negative tile of the same kind make a zero pair: together they add to zero.</p>` : ""}${keyRow}`;
}
function tableHTML(parsed, pickX) {
  const v = singleVar(parsed);
  if (!v) return `<p class="note">A table of values needs exactly one variable. This expression has ${[...E.varsIn(parsed.ast)].length || "no"} variables.</p>`;
  const rows = [-3, -2, -1, 0, 1, 2, 3].map((x) => {
    const val = E.tryEval(parsed.ast, { [v]: new E.Fr(x) });
    return `<tr data-x="${x}" class="${x === pickX ? "pick" : ""}"><td>${x < 0 ? M + Math.abs(x) : x}</td><td>${val ? fmtFr(val) : "undefined"}</td></tr>`;
  }).join("");
  return `<table class="tov"><thead><tr><th>${v}</th><th>value</th></tr></thead><tbody>${rows}</tbody></table><p class="note">Pick a row to see the substitution worked out in step 6.</p>`;
}
function niceStep(range) { const raw = range / 6; const p = Math.pow(10, Math.floor(Math.log10(raw))); for (const m of [1, 2, 5, 10]) if (m * p >= raw) return m * p; return 10 * p; }
function graphHTML(parsed) {
  const v = singleVar(parsed);
  if (!v) return `<p class="note">A graph here needs exactly one variable.</p>`;
  const X0 = -5, X1 = 5;
  const ints = []; for (let x = X0; x <= X1; x++) { const y = evalFloat(parsed.ast, x, v); if (isFinite(y)) ints.push(y); }
  let ymin = Math.min(0, ...ints), ymax = Math.max(0, ...ints);
  ymin = Math.max(ymin, -60); ymax = Math.min(ymax, 60);
  if (ymax - ymin < 4) { ymax += 2; ymin -= 2; }
  const pad = (ymax - ymin) * 0.08; ymin -= pad; ymax += pad;
  const W = 440, H = 300, L = 36, R = 10, T = 10, B = 26;
  const sx = (x) => L + ((x - X0) / (X1 - X0)) * (W - L - R);
  const sy = (y) => T + ((ymax - y) / (ymax - ymin)) * (H - T - B);
  let g = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Graph of y equals the expression for ${v} from −5 to 5">`;
  for (let x = X0; x <= X1; x++) g += `<line class="g-grid" x1="${sx(x)}" y1="${T}" x2="${sx(x)}" y2="${H - B}"/><text class="g-lab" x="${sx(x)}" y="${H - 8}" text-anchor="middle">${x < 0 ? M + Math.abs(x) : x}</text>`;
  const st = niceStep(ymax - ymin);
  for (let y = Math.ceil(ymin / st) * st; y <= ymax; y += st) g += `<line class="g-grid" x1="${L}" y1="${sy(y)}" x2="${W - R}" y2="${sy(y)}"/><text class="g-lab" x="${L - 6}" y="${sy(y) + 4}" text-anchor="end">${y < 0 ? M + Math.abs(+y.toFixed(2)) : +y.toFixed(2)}</text>`;
  g += `<line class="g-axis" x1="${sx(0)}" y1="${T}" x2="${sx(0)}" y2="${H - B}"/><line class="g-axis" x1="${L}" y1="${sy(0)}" x2="${W - R}" y2="${sy(0)}"/>`;
  let d = "", pen = false;
  for (let i = 0; i <= 400; i++) {
    const x = X0 + (i / 400) * (X1 - X0), y = evalFloat(parsed.ast, x, v);
    if (!isFinite(y) || y < ymin - 1e3 || y > ymax + 1e3) { pen = false; continue; }
    const yy = Math.max(ymin - (ymax - ymin), Math.min(ymax + (ymax - ymin), y));
    d += (pen ? "L" : "M") + sx(x).toFixed(1) + " " + sy(yy).toFixed(1) + " "; pen = true;
  }
  g += `<clipPath id="gclip"><rect x="${L}" y="${T}" width="${W - L - R}" height="${H - T - B}"/></clipPath><path class="g-line" clip-path="url(#gclip)" d="${d}"/>`;
  for (let x = -3; x <= 3; x++) { const y = evalFloat(parsed.ast, x, v); if (isFinite(y) && y >= ymin && y <= ymax) g += `<circle class="g-pt" cx="${sx(x)}" cy="${sy(y)}" r="4"/>`; }
  g += "</svg>";
  return `<div class="graph">${g}</div><p class="note">The dots are the rows of the table. Every point on the line is (${v}, value of the expression).</p>`;
}
function simplifiedHTML(parsed) {
  const p = E.polyOf(parsed.ast);
  if (!p) return `<p class="note">I can't rewrite this one as a polynomial (it may divide by an expression with a variable).</p>`;
  const same = E.polyText(p, false).replace(/\s/g, "") === E.plainText(parsed.ast).replace(/\s|[()]/g, "") ;
  return `<p class="qexpr" style="padding:4px 0">${polyHTML(p)}</p>
    <p class="say">${same ? "This expression is already simplified." : "This is an equivalent expression: it has the same value for every value of the variable."}</p>
    <p class="note">To simplify, expand any brackets (multiply every term inside), then combine like terms. An equivalent form can show something new: which power is highest, or what the value is when the variable is 0.</p>`;
}

/* ---------- Substitute ---------- */
function subHTML(parsed, env) {
  try {
    const steps = E.substitutionSteps(parsed.ast, env);
    return `<ol class="steps">${steps.map((s) => `<li><span>${s}</span></li>`).join("")}</ol>`;
  } catch (e) {
    return `<p class="err">${E.esc(e.friendly ? e.message : "This can't be worked out for that value.")}</p>`;
  }
}
function predictHTML(parsed, env) {
  const v = E.tryEval(parsed.ast, env);
  if (!v) return subHTML(parsed, env);
  const envText = Object.entries(env).map(([k, x]) => `${k} = ${x.n < 0 ? M + Math.abs(x.n) : x.n}`).join(", ");
  return `<div class="predict"><p class="say">Before you calculate: when ${envText}, will the value be…</p>
    <div class="numbtns"><button type="button" class="opt" data-pred="pos">positive</button><button type="button" class="opt" data-pred="neg">negative</button><button type="button" class="opt" data-pred="zero">zero</button><button type="button" class="btn small ghost" data-pred="skip">Just show me</button></div></div>`;
}

/* ============================================================
   Decode view
   ============================================================ */
const EXAMPLES = [
  ["3x² + 2x − 5", ""], ["3x² + x − 2x² + 5x", "like terms"], ["−3x(4x² − 5)", "EQAO"], ["2(x − 3) + 3x", ""],
  ["x(x + 2) + 3(x² + 2x − 5)", "C1.4"], ["(2x + 4y) − (x − y)", ""], ["(2x)(3x²)", ""], ["5 − 2n", ""], ["(m + 8)/2", ""], ["−3²", ""],
];
const D = { parsed: null, show: "tiles", env: {}, boxes: true, labels: false, focus: null };

function buildDecode() {
  $("#examples").innerHTML = "Try: " + EXAMPLES.map(([e, tag]) => `<button class="chip" type="button" data-ex="${e}">${e}${tag ? `<small>${tag}</small>` : ""}</button>`).join("");
  $("#examples").addEventListener("click", (e) => { const b = e.target.closest("[data-ex]"); if (b) { $("#exprIn").value = b.dataset.ex; decode(true); } });
  $("#keys").addEventListener("click", (e) => {
    const b = e.target.closest("[data-k]"); if (!b) return;
    const inp = $("#exprIn"), s = inp.selectionStart ?? inp.value.length, en = inp.selectionEnd ?? s;
    inp.value = inp.value.slice(0, s) + b.dataset.k + inp.value.slice(en);
    inp.focus(); const c = s + b.dataset.k.length; inp.setSelectionRange(c, c);
  });
  $("#decodeForm").addEventListener("submit", (e) => { e.preventDefault(); decode(true); });
  let t; $("#exprIn").addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => decode(false), 450); });
  $("#tBoxes").addEventListener("click", () => { D.boxes = !D.boxes; paintHero(false); });
  $("#tStudent").addEventListener("click", (e) => { const on = document.body.classList.toggle("student-view"); e.currentTarget.setAttribute("aria-pressed", on); });
  $("#copyPlan").addEventListener("click", async (e) => {
    const b = e.currentTarget;
    try { await navigator.clipboard.writeText(planText(D.parsed)); b.textContent = "Copied"; } catch (err) { b.textContent = "Copy blocked: select the text instead"; }
    setTimeout(() => (b.textContent = "Copy plan"), 2200);
  });
  $("#tLabels").addEventListener("click", () => { D.labels = !D.labels; paintHero(false); });
  $("#legend").addEventListener("click", (e) => { const b = e.target.closest("[data-r]"); if (!b || b.disabled) return; D.focus = D.focus === b.dataset.r ? null : b.dataset.r; paintHero(false); });
  $("#showTabs").addEventListener("click", (e) => { const b = e.target.closest("[data-show]"); if (!b || b.disabled) return; D.show = b.dataset.show; paintShow(); });
  $("#p-show").addEventListener("click", (e) => { const r = e.target.closest("tr[data-x]"); if (r && D.parsed) { const v = singleVar(D.parsed); D.env[v] = new E.Fr(+r.dataset.x); paintSub(); paintShow(); } });
}
function decode(fromUser) {
  const src = $("#exprIn").value.trim();
  if (D.parsed && src === D.lastSrc && !fromUser) return;
  const r = tryParse(src);
  if (r.err) { if (fromUser || src.length > 0) $("#err").textContent = r.err; return; }
  $("#err").textContent = "";
  D.parsed = r.p; D.focus = null; D.lastSrc = src; D.predicted = false;
  const vars = [...E.varsIn(r.p.ast)].sort();
  const env = {}; vars.forEach((v, i) => (env[v] = D.env[v] && D.env[v].isInt ? D.env[v] : new E.Fr(i === 0 ? 2 : 3)));
  D.env = env;
  if (!singleVar(r.p) && D.show !== "simp") D.show = "simp";
  paintHero(true); paintPanels(); snapshot();
}
function paintHero(animate) {
  const p = D.parsed; if (!p) return;
  const el = $("#hero");
  el.className = "bigexpr colour" + (animate ? " fresh" : "") + (D.focus ? " focus-" + D.focus : "");
  el.innerHTML = exprHTML(p, D.boxes ? { termSet: termSetOf(p) } : {});
  decorate(el, { labels: true, animate, parsed: p });
  $("#stage").classList.toggle("boxes", D.boxes);
  $("#stage").classList.toggle("labels", D.labels);
  $("#tBoxes").setAttribute("aria-pressed", D.boxes);
  $("#tLabels").setAttribute("aria-pressed", D.labels);
  const counts = {}; p.toks.forEach((t) => (counts[t.role] = (counts[t.role] || 0) + 1));
  $("#legend").innerHTML = ROLE_ORDER.map((r) => `<button type="button" data-r="${r}" aria-pressed="${D.focus === r}" ${counts[r] ? "" : "disabled"}><i style="background:var(--r-${r})"></i>${ROLE_PLURAL[r]}</button>`).join("");
  if (animate) setTimeout(() => el.classList.remove("fresh"), 900);
}
function paintPanels() {
  const p = D.parsed;
  $("#scan").innerHTML = scanHTML(p);
  $("#split").innerHTML = splitHTML(p);
  $("#spot").innerHTML = spotHTML(p);
  $("#say").innerHTML = sayHTML(p);
  ["scan", "split", "spot", "say", "show", "sub"].forEach((k, i) => ($("#t-" + k).innerHTML = teachBoxHTML(p, i)));
  $("#plan").innerHTML = planHTML(p);
  paintShow(); paintSub();
}
function paintShow() {
  const p = D.parsed, one = !!singleVar(p);
  $$("#showTabs [data-show]").forEach((b) => { b.disabled = (b.dataset.show === "table" || b.dataset.show === "graph") && !one; b.setAttribute("aria-selected", b.dataset.show === D.show); });
  const x = one ? D.env[singleVar(p)].n : null;
  $("#show").innerHTML = (D.show === "tiles" ? tilesHTML(p) : D.show === "table" ? tableHTML(p, x) : D.show === "graph" ? graphHTML(p) : simplifiedHTML(p))
    + why("Changing forms, from symbols to tiles, a table, a graph or words, is where much of the learning happens, and each direction is its own skill. Tiles are the concrete step in a build, draw, write sequence.", "duval", "witzel", "moschkovich");
}
function paintSub() {
  const p = D.parsed;
  const vars = Object.keys(D.env);
  $("#subctl").innerHTML = (vars.length ? vars.map((v) => `<label for="s-${v}"><i>${v}</i> = <input type="range" id="s-${v}" data-v="${v}" min="-5" max="5" step="1" value="${D.env[v].n}"><output>${D.env[v].n < 0 ? M + Math.abs(D.env[v].n) : D.env[v].n}</output></label>`).join("") : `<span class="note">No variables here, so just work it out.</span>`)
    + `<button type="button" class="toggle" id="tPredict" aria-pressed="${!D.skipPredict}">Predict first</button>`;
  $$("#subctl input").forEach((inp) => inp.addEventListener("input", () => {
    D.env[inp.dataset.v] = new E.Fr(+inp.value);
    inp.nextElementSibling.textContent = +inp.value < 0 ? M + Math.abs(+inp.value) : inp.value;
    D.predicted = false; paintSubBody();
    if (D.show === "table") paintShow();
  }));
  $("#tPredict").addEventListener("click", () => { D.skipPredict = !D.skipPredict; D.predicted = false; paintSub(); });
  paintSubBody();
}
function paintSubBody() {
  const p = D.parsed;
  $("#sub").innerHTML = (D.skipPredict || D.predicted ? (D.predictFb || "") + subHTML(p, D.env) : predictHTML(p, D.env))
    + why("Predicting first, then checking by substituting, is part of symbol sense: you read meaning through the symbols instead of only pushing them around.", "arcavi");
  D.predictFb = "";
}
function onPredict(kind) {
  const p = D.parsed, v = E.tryEval(p.ast, D.env);
  if (kind !== "skip" && v) {
    const actual = v.zero ? "zero" : v.negative ? "neg" : "pos";
    const name = { pos: "positive", neg: "negative", zero: "zero" };
    D.predictFb = `<p class="${actual === kind ? "fbline good" : "fbline bad"}">${actual === kind ? "Your prediction holds." : `You predicted ${name[kind]}; it is ${name[actual]}.`} Check each step below. What told you the sign?</p>`;
  }
  D.predicted = true; paintSubBody();
}
document.addEventListener("click", (e) => { const b = e.target.closest("#sub [data-pred]"); if (b) onPredict(b.dataset.pred); });

/* ============================================================
   Learn view — the 6 S routine and a worked example
   ============================================================ */
const SIX = [
  ["Scan", "What kind of expression is it?", "Look before you do. Find the + and − signs outside brackets, and name the principal operation: the one done last. Squint so each bracket group looks like one box.", "The principal operation is ___, so this is a ___."],
  ["Split", "Where does each term start and end?", "Box each term. Keep the sign in front with its term. A bracket group stays inside one box.", "The terms are ___. The sign in front of ___ is ___."],
  ["Spot", "What is each part called?", "In each term, name the coefficient, variable, exponent and constant. Look for like terms.", "In ___, the coefficient is ___ and the variable is ___."],
  ["Say", "How do I read it aloud?", "Start in everyday words if that helps. Then say it symbol by symbol, using “the quantity” for brackets, and finally by meaning: a sum, difference, product or quotient of what?", "This is the ___ of ___ and ___."],
  ["Show", "What else could show this?", "Build it with algebra tiles, make a table of values, sketch a graph, or write an equivalent expression.", "I can show this with ___ because ___."],
  ["Substitute", "Does my reading hold up?", "Predict the sign first. Then put a number in brackets for the variable and work it out in order: brackets, exponents, multiply/divide, add/subtract.", "I predicted ___. When x = ___, it equals ___."],
];
const WALK_EX = ["−3x(4x² − 5)", "3x² + x − 2x² + 5x", "2(x − 3) + 3x", "(x + 1)²"];
const W = { ex: WALK_EX[0], step: 0 };

function buildLearn() {
  buildRoutine();
  $("#walkSel").innerHTML = WALK_EX.map((e) => `<option>${e}</option>`).join("");
  $("#walkSel").addEventListener("change", (e) => { W.ex = e.target.value; W.step = 0; paintWalk(); });
  $("#walkDots").innerHTML = SIX.map((s, i) => `<button type="button" data-step="${i}" aria-label="Step ${i + 1}: ${s[0]}">${i + 1}</button>`).join("");
  $("#walkDots").addEventListener("click", (e) => { const b = e.target.closest("[data-step]"); if (b) { W.step = +b.dataset.step; paintWalk(); } });
  $("#walkPrev").addEventListener("click", () => { if (W.step > 0) { W.step--; paintWalk(); } });
  $("#walkNext").addEventListener("click", () => { if (W.step < 5) { W.step++; paintWalk(); } else { $("#exprIn").value = W.ex; go("decode"); decode(true); } });
  $("#walkTry").addEventListener("click", () => { $("#exprIn").value = W.ex; go("decode"); decode(true); });
  paintWalk();
}
function thinkAloud(p, step) {
  const ts = E.analyzeTerms(p), mo = E.mainOperation(p.ast);
  const v = [...E.varsIn(p.ast)][0] || "x";
  switch (step) {
    case 0: return `Before I do anything, I look. I find the + and ${M} signs that are <b>not</b> inside brackets. ${mo.text} In words: the principal operation is <b>${E.principal(p.ast).op}</b>.`;
    case 1: return ts.length === 1 ? `Everything is held together by brackets or multiplication, so the whole thing is <b>one term</b>. That matters: whatever is outside the bracket multiplies <b>every</b> term inside it.` : `I box each term and keep the sign in front with it. ${ts.some((t) => t.likeGroup) ? "Some terms share the same variable part, so I tag them as like terms." : ""}`;
    case 2: return `Now I name the parts of each term. The coefficient is the number multiplying the variable, sign included.`;
    case 3: return `I read it out loud two ways. Symbol by symbol helps me say it accurately. By meaning tells me what the expression <b>does</b>.`;
    case 4: return E.polyOf(p.ast) ? `I show it another way. ${tileable(E.polyOf(p.ast), v) ? "Algebra tiles let me see the terms." : "A simplified, equivalent form tells me what it really equals."}` : `I show it with a table of values.`;
    case 5: return `Finally I check by substituting ${v} = 2. I work in order: brackets, exponents, multiplying, then adding and subtracting.`;
  }
}
function paintWalk() {
  const p = E.parse(W.ex);
  $("#walkSel").value = W.ex;
  $$("#walkDots button").forEach((b, i) => { b.setAttribute("aria-current", i === W.step ? "step" : "false"); b.classList.toggle("done", i < W.step); });
  $("#walkTitle").innerHTML = `<span class="sn">${W.step + 1}</span> ${SIX[W.step][0]}: ${SIX[W.step][1]}`;
  const hero = $("#walkExpr");
  hero.className = "bigexpr colour" + (W.step >= 2 ? "" : " plain");
  hero.innerHTML = exprHTML(p, W.step >= 1 ? { termSet: termSetOf(p) } : {});
  $("#walkStage").classList.toggle("boxes", W.step >= 1);
  $("#walkStage").classList.toggle("labels", W.step === 2);
  decorate(hero, { parsed: p });
  if (W.step < 2) $$(".tk", hero).forEach((t) => (t.style.color = "var(--ink)"));
  $("#walkThink").innerHTML = "“" + thinkAloud(p, W.step) + "”";
  $("#walkAsk").innerHTML = teachMoves(p, W.step).ask.map((a) => `<li>${E.esc(a)}</li>`).join("");
  const v = [...E.varsIn(p.ast)][0] || "x";
  const body = [scanHTML, splitHTML, spotHTML, sayHTML, (q) => (tileable(E.polyOf(q.ast), v) ? tilesHTML(q) : simplifiedHTML(q)), (q) => subHTML(q, { [v]: new E.Fr(2) })][W.step](p);
  $("#walkBody").innerHTML = body;
  $("#walkPrev").disabled = W.step === 0;
  $("#walkNext").textContent = W.step < 5 ? "Next step" : "Open in Model it";
}

/* ============================================================
   Practice
   ============================================================ */
const P = { mode: "say", right: 0, tried: 0, streak: 0, q: null };
const MODES = [
  ["say", "Say it right", "Pick the correct way to read an expression.", "Say"],
  ["write", "Write it", "Turn words into an expression.", "Say"],
  ["spot", "Spot the part", "Tap the coefficient, constant, exponent…", "Split & Spot"],
  ["error", "Find the error", "Find the wrong line in a worked example and say why.", "Scan & Substitute"],
  ["same", "Same or different?", "Decide if two expressions are equivalent.", "Show & Substitute"],
  ["tiles", "Match the tiles", "Tiles → symbols: find the expression.", "Show"],
  ["build", "Build it", "Symbols → tiles: build the expression.", "Show"],
  ["words", "Word check", "Pick the example that fits the math word.", "Spot"],
];
const ERROR_BANK = [
  { task: "Simplify 2(x − 3) + 3x.", steps: ["2(x − 3) + 3x", "= 2x − 3 + 3x", "= 5x − 3"], bad: 1, why: ["The 2 multiplied x but not −3.", "2x and 3x are not like terms.", "The bracket should have been removed by adding."], fix: ["2(x − 3) + 3x", "= 2x − 6 + 3x", "= 5x − 6"], rule: "Distributive property: the factor outside the bracket multiplies every term inside it.", cites: ["star", "booth"] },
  { task: "Expand (x + 3)².", steps: ["(x + 3)²", "= x² + 3²", "= x² + 9"], bad: 1, why: ["Squaring a sum is not the same as squaring each term: (x + 3)² means (x + 3)(x + 3).", "3² should be 6.", "x² should be 2x."], fix: ["(x + 3)²", "= (x + 3)(x + 3)", "= x² + 3x + 3x + 9", "= x² + 6x + 9"], rule: "A power of a product splits: (xy)² = x²y². A power of a sum does not.", cites: ["kirshner", "booth"] },
  { task: "Simplify (2x)³.", steps: ["(2x)³", "= 2x³"], bad: 1, why: ["The exponent applies to the whole bracket, so the 2 is cubed too.", "It should be 6x³ because 2 × 3 = 6.", "It should be 2x⁹."], fix: ["(2x)³", "= 2x · 2x · 2x", "= 8x³"], rule: "An exponent outside a bracket applies to everything inside the bracket.", cites: ["kirshner"] },
  { task: "Simplify x² · x³.", steps: ["x² · x³", "= x⁶"], bad: 1, why: ["Multiplying powers with the same base adds the exponents.", "It should be 2x⁵.", "It should be x⁵ + x."], fix: ["x² · x³", "= (x · x)(x · x · x)", "= x⁵"], rule: "Multiplying powers with the same base: keep the base, add the exponents.", cites: ["kirshner"] },
  { task: "Simplify −(x − 4).", steps: ["−(x − 4)", "= −x − 4"], bad: 1, why: ["The opposite applies to every term: the opposite of −4 is +4.", "It should be x + 4.", "It should be −x + 4x."], fix: ["−(x − 4)", "= −x + 4"], rule: "Taking the opposite of a bracket changes the sign of every term inside.", cites: ["rubenstein", "booth"] },
  { task: "Simplify 3x² + 2x².", steps: ["3x² + 2x²", "= 5x⁴"], bad: 1, why: ["Combining like terms adds the coefficients; the variable part stays x².", "It should be 6x².", "It should be 5x² · x²."], fix: ["3x² + 2x²", "= (3 + 2)x²", "= 5x²"], rule: "Combining like terms: add the coefficients and keep the variable part.", cites: ["booth"] },
  { task: "Simplify 3 + 2x.", steps: ["3 + 2x", "= 5x"], bad: 1, why: ["3 and 2x are not like terms, so 3 + 2x is already simplified.", "It should be 6x.", "It should be 5."], fix: ["3 + 2x", "(already simplified)"], rule: "Only like terms can be combined. A constant and an x-term are not like terms.", cites: ["booth"] },
  { task: "Evaluate −x² when x = −3.", steps: ["−x²", "= −(−3)²", "= 3²", "= 9"], bad: 2, why: ["The square happens before the opposite: (−3)² = 9, then the opposite gives −9.", "(−3)² should be −9.", "x should have been replaced by 3, not −3."], fix: ["−x²", "= −(−3)²", "= −(9)", "= −9"], rule: "In −x², x is squared first, then the opposite is taken. Put a substituted value in brackets.", cites: ["rubenstein", "arcavi"] },
  { task: "Evaluate 2+3 × 4.", steps: ["2+3&ensp;&ensp;× 4", "= 5 × 4", "= 20"], bad: 1, why: ["Multiplication comes before addition, however the symbols are spaced.", "2 + 3 should be 6.", "5 × 4 should be 24."], fix: ["2 + 3×4", "= 2 + 12", "= 14"], rule: "Spacing never changes the order of operations: multiply before you add.", cites: ["landy"] },
  { task: "Con is h cm tall. David is 10 cm taller. Write David's height.", steps: ["h is the 8th letter", "so h = 8", "David: 10 + 8 = 18 cm"], bad: 0, why: ["A letter stands for an unknown number, not its place in the alphabet. David's height is h + 10.", "h should equal 10.", "David's height should be 10h."], fix: ["Con: h cm", "David: h + 10 cm"], rule: "A letter stands for a number. It is not a code for its place in the alphabet.", cites: ["macgregorStacey"] },
  { task: "Simplify x + x + x.", steps: ["x + x + x", "= x³"], bad: 1, why: ["Adding three x's gives 3x (3 times x); x³ means x times x times x.", "It should be x + 3.", "It should be 3x³."], fix: ["x + x + x", "= 3x"], rule: "Repeated addition is multiplication by a number (3x). Repeated multiplication is a power (x³).", cites: ["macgregorStacey"] },
  { task: "Simplify 5 − 2(x + 1).", steps: ["5 − 2(x + 1)", "= 3(x + 1)", "= 3x + 3"], bad: 1, why: ["The 2 multiplies the bracket first, so 5 − 2 can't be done first.", "It should be 7(x + 1).", "3(x + 1) should be 3x + 1."], fix: ["5 − 2(x + 1)", "= 5 − 2x − 2", "= −2x + 3"], rule: "Multiply before you subtract: expand 2(x + 1) first, then combine.", cites: ["landy", "booth"] },
];
const BUILD_BANK = ["2x + 3", "x² − 2x + 1", "2(x − 3)", "3x − 5 + x", "−x² + 4", "x(x + 2)", "−2(x + 1)", "2x² − x − 3", "3 − x", "x² + x − x² + 2"];
const WORDCHECK_BANK = [
  ["Which pair are <b>like terms</b>?", ["4x and −x", "4x and 4x²", "4x and 4", "4x and 4y"]],
  ["Which is a <b>binomial</b>?", ["3x − 7", "3x(x − 7)", "3x² − x + 7", "−7x"]],
  ["Which has a <b>constant term</b> of −5?", ["2x² − 5", "−5x + 2", "5 − 2x", "x − 5x"]],
  ["In which is the <b>coefficient</b> of x equal to −3?", ["4 − 3x", "3 − x", "x − 3", "−x³"]],
  ["Which has <b>degree</b> 3?", ["x²y + 2", "3x + 2", "x² + 3", "3x²"]],
  ["Which is a <b>product</b> (principal operation: multiplication)?", ["2(x + 5)", "2x + 5", "x² + 5x", "x − 2 + 5"]],
  ["Which pair are <b>equivalent expressions</b>?", ["2m + 10 and 2(m + 5)", "2m + 10 and 2(m + 10)", "m + 5 and 2(m + 5)", "2m + 5 and 2(m + 5)"]],
  ["Which uses <b>“product”</b> with its math meaning?", ["The product of 4 and x is 4x.", "The store has a new product.", "This shampoo is my favourite product.", "Cars are the factory's main product."]],
  ["Which uses <b>“term”</b> with its math meaning?", ["3x² + 2x has two terms.", "The school term ends in June.", "The lease has a two-year term.", "They are on good terms."]],
  ["Which uses <b>“degree”</b> with its math meaning?", ["x³ has degree 3.", "It's 20 degrees outside.", "She has a degree in history.", "To some degree, I agree."]],
  ["Which uses <b>“power”</b> with its math meaning?", ["2⁵ is a power of 2.", "The power went out last night.", "Knowledge is power.", "That car has a lot of power."]],
  ["Which shows the <b>distributive property</b> used correctly?", ["4(x − 2) = 4x − 8", "4(x − 2) = 4x − 2", "4(x − 2) = 4x + 8", "4(x − 2) = x − 8"]],
];
const SAY_BANK = [
  ["3(x + 2)", "3 times the quantity x plus 2", ["3 times x, plus 2", "3 plus the quantity x plus 2", "the quantity 3 plus x, times 2"]],
  ["x² + 5", "x squared plus 5", ["2 times x, plus 5", "the quantity x plus 5, squared", "x plus 5 squared"]],
  ["(x + 5)²", "the quantity x plus 5, squared", ["x squared plus 5", "x plus 5 squared", "2 times the quantity x plus 5"]],
  ["5 − x", "x less than 5", ["5 less than x", "x take away 5", "the difference of x and 5"]],
  ["2x³", "2 times x cubed", ["the quantity 2x, cubed", "2 times x times 3", "x to the power of 2 times 3"]],
  ["(2x)³", "the quantity 2x, cubed", ["2 times x cubed", "2x times 3", "2 cubed plus x cubed"]],
  ["−3²", "the opposite of 3 squared", ["negative 3, all squared", "3 squared minus 3", "negative 3 times 2"]],
  ["−3x(4x² − 5)", "negative 3x times the quantity 4x squared minus 5", ["negative 3x times 4x squared, minus 5", "negative 3x plus the quantity 4x squared minus 5", "the quantity negative 3x times 4x, squared, minus 5"]],
  ["a/2 + 7", "a divided by 2, plus 7", ["a divided by the quantity 2 plus 7", "2 divided by a, plus 7", "half of the quantity a plus 7"]],
  ["4 − 2(n + 1)", "4 minus 2 times the quantity n plus 1", ["the quantity 4 minus 2, times the quantity n plus 1", "4 minus 2n, plus 1", "2 times the quantity n plus 1, minus 4"]],
  ["xy²", "x times y squared", ["the quantity x times y, squared", "x squared times y", "2 times x times y"]],
  ["3x + 3", "3 times x, plus 3", ["3 times the quantity x plus 3", "3 to the power of x plus 3", "x plus 3, times 3"]],
];
const WRITE_BANK = [
  ["5 less than x", "x − 5", [["5 − x", "“Less than” flips the order. 5 less than x starts at x and takes 5 away."]]],
  ["the product of 3 and the sum of x and 4", "3(x + 4)", [["3x + 4", "The 3 multiplies the whole sum, so the sum needs brackets."]]],
  ["twice a number n, decreased by 7", "2n − 7", [["7 − 2n", "“Decreased by 7” means you start with 2n and take 7 away."]]],
  ["the square of the sum of x and 1", "(x + 1)²", [["x² + 1", "Square the sum: make the sum first (brackets), then square it."], ["x + 1²", "Only the 1 got squared. Put the sum in brackets first."]]],
  ["the sum of the square of x and 1", "x² + 1", [["(x + 1)²", "Here only x is squared, and then 1 is added."]]],
  ["6 more than triple y", "3y + 6", [["y³ + 6", "Triple means times 3, not to the power of 3."], ["6 − 3y", "“More than” means add."]]],
  ["subtract 4 from 9 times p", "9p − 4", [["4 − 9p", "“Subtract 4 from…” means start with 9p, then take 4 away."]]],
  ["the quotient of a and 3, increased by 2", "a/3 + 2", [["a/(3 + 2)", "The comma tells you: divide first, then add 2 to the result."], ["3/a + 2", "“The quotient of a and 3” keeps the order: a ÷ 3."]]],
  ["negative 2 times the quantity x minus 6", "−2(x − 6)", [["−2x − 6", "Negative 2 multiplies both x and −6, so keep the brackets."]]],
  ["the difference of 10 and a number k", "10 − k", [["k − 10", "“The difference of A and B” keeps the order: A − B."]]],
  ["half of the sum of m and 8", "(m + 8)/2", [["m/2 + 8", "Half of the sum means the whole sum is divided by 2."]]],
  ["the cube of a number w, times 5", "5w³", [["(5w)³", "Only w is cubed, then multiplied by 5."], ["15w", "Cube means power 3, not times 3."]]],
];
const SAME_BANK = [
  ["2(x − 3)", "2x − 3", "The 2 must multiply both x and −3."],
  ["3(x + 2)", "3x + 6", "Distributing 3 to both terms gives 3x + 6."],
  ["x(x − 4)", "x² − 4x", "x times x is x², and x times −4 is −4x."],
  ["−3x(4x² − 5)", "−12x³ − 5", "−3x was multiplied by 4x² only. It also multiplies −5, giving +15x."],
  ["−3x(4x² − 5)", "−12x³ + 15x", "−3x times 4x² is −12x³, and −3x times −5 is +15x."],
  ["(2x)³", "8x³", "(2x)³ = 2x · 2x · 2x = 8x³."],
  ["(2x)³", "2x³", "In 2x³ only x is cubed; in (2x)³ the 2 is cubed too."],
  ["2m + 10", "2(m + 5)", "Factoring 2 out of 2m + 10 gives 2(m + 5)."],
  ["(x + 1)²", "x² + 1", "(x + 1)² = (x + 1)(x + 1) = x² + 2x + 1, which has a 2x term."],
  ["x² + x²", "2x²", "Two of the same x² term make 2x²."],
  ["x²·x³", "x⁶", "When multiplying powers with the same base, add the exponents: x⁵."],
  ["5 − x", "x − 5", "Subtraction isn't commutative. These are opposites."],
  ["2x(x − 3)", "2x² − 5x", "2x times −3 is −6x, not −5x."],
  ["3x + 5x", "−x + 9x", "Both simplify to 8x."],
];

function buildPractice() {
  $("#modes").innerHTML = MODES.map(([k, t, d, s]) => `<button type="button" class="mode" data-mode="${k}" aria-pressed="${k === P.mode}"><span class="ss">${s}</span><b>${t}</b><span>${d}</span></button>`).join("");
  $("#modes").addEventListener("click", (e) => { const b = e.target.closest("[data-mode]"); if (!b) return; P.mode = b.dataset.mode; $$("#modes .mode").forEach((x) => x.setAttribute("aria-pressed", x === b)); newQ(); });
  $("#qcard").addEventListener("click", onQClick);
  $("#qcard").addEventListener("submit", (e) => { e.preventDefault(); checkWrite(); });
  newQ();
}
function score(ok) { P.tried++; if (ok) { P.right++; P.streak++; } else P.streak = 0; $("#sRight").textContent = P.right; $("#sTried").textContent = P.tried; $("#sStreak").textContent = P.streak; }
function feedback(ok, title, body) {
  const fb = $("#fb"); fb.className = "fb show " + (ok ? "good" : "bad");
  fb.innerHTML = `<h4>${title}</h4>${body}<div class="qactions"><button type="button" class="btn small" data-act="next">Next question</button>${P.q && P.q.decode ? `<button type="button" class="btn small ghost" data-act="decode">Decode it</button>` : ""}</div>`;
  const n = $("[data-act=next]", fb); if (n) n.focus({ preventScroll: true });
}
function colourExpr(src) { const p = E.parse(src); return `<span class="colour">${exprHTML(p)}</span>`; }
function newQ() {
  const box = $("#qcard");
  const m = P.mode;
  if (m === "say") {
    let it; do { it = pick(SAY_BANK); } while (P.q && P.q.item === it && SAY_BANK.length > 1);
    const opts = shuffle([it[1], ...it[2]]);
    P.q = { item: it, answer: it[1], decode: it[0] };
    box.innerHTML = `<p class="qprompt">Which is the correct way to read this expression?</p><div class="qexpr">${colourExpr(it[0])}</div><div class="opts">${opts.map((o) => `<button type="button" class="opt" data-ans="${E.esc(o)}">${E.esc(o)}</button>`).join("")}</div><div id="fb" class="fb" aria-live="polite"></div>`;
  } else if (m === "write") {
    let it; do { it = pick(WRITE_BANK); } while (P.q && P.q.item === it);
    P.q = { item: it, decode: it[1] };
    box.innerHTML = `<p class="qprompt">Write an expression for:</p><p class="qexpr" style="font-family:var(--font-body);font-size:1.6rem;white-space:normal">“${E.esc(it[0])}”</p>
      <form class="inrow" id="writeForm"><label class="sr" for="writeIn">Your expression</label><input id="writeIn" autocomplete="off" spellcheck="false" placeholder="e.g. 3(x + 4)"><button class="btn">Check</button></form>
      <div class="keys">${["²", "³", "(", ")", "−", "/"].map((k) => `<button type="button" data-wk="${k}">${k}</button>`).join("")}</div>
      <div id="fb" class="fb" aria-live="polite"></div>`;
    $("#writeIn").focus({ preventScroll: true });
  } else if (m === "spot") newSpot(box);
  else if (m === "same") {
    let it; do { it = pick(SAME_BANK); } while (P.q && P.q.item === it);
    const flip = Math.random() < 0.5; const a = flip ? it[1] : it[0], b = flip ? it[0] : it[1];
    P.q = { item: it, a, b, decode: a };
    box.innerHTML = `<p class="qprompt">Are these two expressions equivalent?</p><div class="pair"><div class="qexpr">${colourExpr(a)}</div><span class="vs">and</span><div class="qexpr">${colourExpr(b)}</div></div>
      <div class="opts two"><button type="button" class="opt" data-same="1">Same: equivalent</button><button type="button" class="opt" data-same="0">Different: not equivalent</button></div><div id="fb" class="fb" aria-live="polite"></div>`;
  } else if (m === "tiles") newTiles(box);
  else if (m === "error") newError(box);
  else if (m === "build") newBuild(box);
  else if (m === "words") {
    let it; do { it = pick(WORDCHECK_BANK); } while (P.q && P.q.item === it);
    P.q = { item: it, answer: it[1][0] };
    const sentence = (o) => /[a-z]{3,} [a-z]{2,}/i.test(o.replace(/ and /g, " "));
    box.innerHTML = `<p class="qprompt">${it[0]}</p><div class="opts two">${shuffle(it[1]).map((o) => `<button type="button" class="opt${sentence(o) ? "" : " math"}" data-ans="${E.esc(o)}">${E.esc(o)}</button>`).join("")}</div><div id="fb" class="fb" aria-live="polite"></div>`;
  }
}
function newError(box) {
  let it; do { it = pick(ERROR_BANK); } while (P.q && P.q.item === it);
  P.q = { item: it, stage: 1 };
  box.innerHTML = `<p class="qprompt">${E.esc(it.task)} This work has a mistake. Tap the <b>first</b> line that is wrong.</p>
    <ol class="work" id="work">${it.steps.map((s, i) => `<li><button type="button" class="wline" data-line="${i}">${s}</button></li>`).join("")}</ol>
    <div id="whyBox"></div><div id="fb" class="fb" aria-live="polite"></div>`;
}
function errorStage2(ok) {
  const it = P.q.item;
  P.q.lineOk = ok; P.q.stage = 2;
  $$("#work .wline").forEach((b, i) => { b.disabled = true; if (i === it.bad) b.classList.add("badline"); });
  $("#whyBox").innerHTML = `<p class="qprompt">${ok ? "Yes, that's the first wrong line." : "Not that one. The first wrong line is outlined."} Why is it wrong?</p><div class="opts">${shuffle(it.why).map((w) => `<button type="button" class="opt" data-why="${E.esc(w)}">${E.esc(w)}</button>`).join("")}</div>`;
}
function errorDone(choice) {
  const it = P.q.item, ok = choice === it.why[0];
  $$("#whyBox .opt").forEach((b) => { b.disabled = true; if (b.dataset.why === it.why[0]) b.classList.add("right"); else if (b.dataset.why === choice) b.classList.add("wrong"); });
  score(ok && P.q.lineOk);
  const col = (arr, cls) => `<ol class="work ${cls}">${arr.map((s) => `<li>${s}</li>`).join("")}</ol>`;
  feedback(ok, ok ? "Good explaining." : "Not quite.", `<div class="compare"><div><h5>Incorrect work</h5>${col(it.steps, "wrongcol")}</div><div><h5>Correct work</h5>${col(it.fix, "rightcol")}</div></div>
    <p><b>The rule in words:</b> ${E.esc(it.rule)}</p><p class="talk"><b>Talk:</b> Why might someone make this mistake? How would you help them?</p><p class="note">Research: ${cite(...it.cites)}</p>`);
}
function newBuild(box) {
  let src; do { src = pick(BUILD_BANK); } while (P.q && P.q.src === src);
  P.q = { src, decode: src, tiles: { x2: 0, nx2: 0, x: 0, nx: 0, u: 0, nu: 0 } };
  box.innerHTML = `<p class="qprompt">Build this expression with algebra tiles:</p><div class="qexpr">${colourExpr(src)}</div>
    <div class="builder"><div class="tilebtns">${[["x2", "+x²"], ["nx2", "−x²"], ["x", "+x"], ["nx", "−x"], ["u", "+1"], ["nu", "−1"]].map(([k, l]) => `<button type="button" class="opt" data-add="${k}">${l}</button>`).join("")}
      <button type="button" class="btn small ghost" data-act2="zero">Remove zero pairs</button><button type="button" class="btn small ghost" data-act2="clear">Clear</button></div>
      <div id="mat" class="mat" aria-live="polite"></div>
      <div class="qactions"><button type="button" class="btn" data-act2="check">Check my tiles</button></div></div>
    <div id="fb" class="fb" aria-live="polite"></div>`;
  paintMat();
}
function paintMat() {
  const t = P.q.tiles;
  const tile = (cls, neg, lab, n) => Array.from({ length: n }, () => `<span class="tile ${cls}${neg ? " neg" : ""}"><span>${neg ? M : ""}${lab}</span></span>`).join("");
  const html = tile("x2", false, "x²", t.x2) + tile("x2", true, "x²", t.nx2) + tile("x", false, "x", t.x) + tile("x", true, "x", t.nx) + tile("u", false, "1", t.u) + tile("u", true, "1", t.nu);
  $("#mat").innerHTML = html ? `<div class="tset" style="max-width:none">${html}</div>` : `<p class="note">Your mat is empty. Add tiles with the buttons.</p>`;
}
function checkBuild() {
  const t = P.q.tiles, p = E.polyOf(E.parse(P.q.src).ast);
  const g = (k) => (p.get(k) ? p.get(k).c.n : 0);
  const need = { x2: g("x^2"), x: g("x^1"), u: g("") };
  const have = { x2: t.x2 - t.nx2, x: t.x - t.nx, u: t.u - t.nu };
  const ok = need.x2 === have.x2 && need.x === have.x && need.u === have.u;
  score(ok);
  const name = { x2: "x² tiles", x: "x tiles", u: "1 tiles" };
  const off = Object.keys(need).filter((k) => need[k] !== have[k]).map((k) => `${name[k]}: your net is ${have[k]}, the expression needs ${need[k]}`);
  const pairs = Math.min(t.x2, t.nx2) + Math.min(t.x, t.nx) + Math.min(t.u, t.nu);
  feedback(ok, ok ? "Your tiles match." : "Not yet.", ok ? `<p>Your tiles show <span class="math">${polyHTML(p)}</span>: the same expression in a different form.${pairs ? " The zero pairs on your mat add to zero, so they don't change the value." : ""}</p><p class="note">${cite("duval", "witzel")}</p>` : `<p>${off.join("<br>")}</p><p class="note">Net means positive tiles minus negative tiles. A zero pair adds to zero.</p>`);
}
function newSpot(box) {
  const v = pick(["x", "x", "n", "a", "y"]);
  const sg = () => (Math.random() < 0.5 ? "+" : M);
  const a = rint(2, 9), b = rint(2, 9), c = rint(1, 9);
  const lead = Math.random() < 0.3 ? M : "";
  const templates = [
    `${lead}${a}${v}² ${sg()} ${b}${v} ${sg()} ${c}`,
    `${c} ${sg()} ${b}${v}`,
    `${lead}${b}${v} ${sg()} ${c}`,
    `${a}(${v} ${sg()} ${c})`,
    `${lead}${a}${v}³ ${sg()} ${b}${v}`,
    `${c} ${sg()} ${a}${v}² ${sg()} ${b}${v}`,
  ];
  const src = pick(templates);
  const p = E.parse(src);
  const ts = E.analyzeTerms(p);
  const qs = [];
  const termToks = (t) => { const out = []; (function walk(n) { if (n.tok !== undefined && n.tok >= 0) out.push(n.tok); if (n.lp) out.push(...n.lp, ...n.rp); if (n.arg) walk(n.arg); if (n.left) { walk(n.left); walk(n.right); } })(t.node); if (t.opTok !== null && t.opTok !== undefined) out.push(t.opTok); return out; };
  ts.forEach((t) => {
    if (!t.mono || !t.simple) return;
    const toks = termToks(t);
    const signTok = t.sign < 0 && t.opTok !== null ? [t.opTok] : [];
    if (t.varPart) qs.push({ text: `Tap the coefficient of the <span class="math">${t.varPart}</span> term.`, targets: [...toks.filter((k) => p.toks[k].role === "coef"), ...signTok], explain: `The coefficient of <span class="math">${t.varPart}</span> is <b class="math">${fmtFr(t.mono.c)}</b>.${t.mono.c.negative ? " The minus sign in front of the term belongs to the coefficient." : ""}` });
    else qs.push({ text: "Tap the constant term.", targets: [...toks.filter((k) => p.toks[k].role === "const"), ...signTok], explain: `The constant term is <b class="math">${fmtFr(t.mono.c)}</b>. It has no variable, so its value never changes.` });
  });
  const expToks = p.toks.map((t, i) => (t.role === "exp" ? i : -1)).filter((i) => i >= 0);
  if (expToks.length) qs.push({ text: "Tap an exponent.", targets: expToks, explain: "The exponent is the small raised number. It tells how many times the base is used as a factor." });
  qs.push({ text: "Tap the variable.", targets: p.toks.map((t, i) => (t.role === "var" ? i : -1)).filter((i) => i >= 0), explain: `<span class="math"><i>${v}</i></span> is the variable: a letter that stands for a number.` });
  const count = ts.length;
  qs.push({ count, text: "How many terms does this expression have?", explain: count === 1 ? "One term: the bracket keeps everything together, and the number in front multiplies the whole bracket." : `${count} terms, separated by the + and ${M} signs outside brackets.` });
  const q = pick(src.includes("(") ? qs.filter((x) => x.count || /constant|variable/.test(x.text)) : qs);
  P.q = { src, p, q, decode: src };
  box.innerHTML = `<p class="qprompt">${q.text}</p><div class="qexpr${q.count ? "" : " tap"}" id="spotExpr">${exprHTML(p)}</div>
    ${q.count ? `<div class="numbtns">${[1, 2, 3, 4].map((n) => `<button type="button" class="opt" data-count="${n}">${n}</button>`).join("")}</div>` : `<p class="note">Tap or click a part of the expression.</p>`}
    <div id="fb" class="fb" aria-live="polite"></div>`;
  if (!q.count) $$("#spotExpr .tk[data-tok]").forEach((t) => { t.setAttribute("role", "button"); t.tabIndex = 0; t.setAttribute("aria-label", t.textContent || "caret"); });
  $$("#spotExpr .caret").forEach((t) => t.removeAttribute("data-tok"));
}
function newTiles(box) {
  let a, b, c, key;
  do { a = rint(0, 2); b = rint(-3, 3); c = rint(-4, 4); key = `${a},${b},${c}`; } while ([a, b, c].filter((z) => z !== 0).length < 2 || (P.q && P.q.key === key));
  const mk = (A, B, C) => E.polyOf(E.parse(`${A}x^2 + ${B}x + ${C}`.replace(/\+ -/g, "- ")).ast);
  const right = mk(a, b, c);
  const cands = [[a, -b, c], [a, b, -c], [b, a, c], [a, c, b], [-a, b, c], [a, -b, -c], [c, b, a]].filter(([A, B, C]) => Math.abs(A) <= 4 && Math.abs(B) <= 6 && Math.abs(C) <= 6);
  const opts = [right]; const seen = new Set([E.polyText(right, false)]);
  for (const [A, B, C] of shuffle(cands)) { const q = mk(A, B, C); const k = E.polyText(q, false); if (!seen.has(k) && q.size) { seen.add(k); opts.push(q); } if (opts.length === 4) break; }
  P.q = { key, answer: E.polyText(right, false), decode: E.polyText(right, false).replace(/²/g, "^2") };
  box.innerHTML = `<p class="qprompt">Which expression do these algebra tiles show?</p><div class="tiles" style="justify-content:center">${tilesFor(right, "x")}</div>
    <p class="note" style="text-align:center">Blue square: x² · green bar: x · small yellow square: 1 · red: negative</p>
    <div class="opts two">${shuffle(opts).map((o) => `<button type="button" class="opt math" data-ans="${E.esc(E.polyText(o, false))}">${polyHTML(o)}</button>`).join("")}</div><div id="fb" class="fb" aria-live="polite"></div>`;
}
function lockOpts() { $$("#qcard .opt").forEach((b) => (b.disabled = true)); }
function onQClick(e) {
  const t = e.target;
  const act = t.closest("[data-act]");
  if (act) { if (act.dataset.act === "next") newQ(); else { $("#exprIn").value = P.q.decode; go("decode"); decode(true); } return; }
  const wk = t.closest("[data-wk]");
  if (wk) { const inp = $("#writeIn"); const s = inp.selectionStart ?? inp.value.length; inp.value = inp.value.slice(0, s) + wk.dataset.wk + inp.value.slice(inp.selectionEnd ?? s); inp.focus(); inp.setSelectionRange(s + 1, s + 1); return; }
  if (P.mode === "build") {
    if (P.answered) return;
    const a = t.closest("[data-add]"), c = t.closest("[data-act2]");
    if (a) { P.q.tiles[a.dataset.add]++; paintMat(); return; }
    if (c) {
      const T = P.q.tiles;
      if (c.dataset.act2 === "clear") Object.keys(T).forEach((k) => (T[k] = 0));
      if (c.dataset.act2 === "zero") for (const [p, n] of [["x2", "nx2"], ["x", "nx"], ["u", "nu"]]) { const z = Math.min(T[p], T[n]); T[p] -= z; T[n] -= z; }
      if (c.dataset.act2 === "check") { $$("#qcard [data-add], #qcard [data-act2]").forEach((b) => (b.disabled = true)); checkBuild(); return; }
      paintMat();
    }
    return;
  }
  if (P.mode === "error") {
    const l = t.closest("[data-line]"); if (l && P.q.stage === 1) { const ok = +l.dataset.line === P.q.item.bad; if (!ok) l.classList.add("picked"); errorStage2(ok); return; }
    const w = t.closest("[data-why]"); if (w && P.q.stage === 2) { P.q.stage = 3; errorDone(w.dataset.why); }
    return;
  }
  if (P.answered) return;
  if (P.mode === "words") {
    const b = t.closest("[data-ans]"); if (!b) return;
    const ok = b.dataset.ans === P.q.answer; lockOpts(); b.classList.add(ok ? "right" : "wrong");
    $$("#qcard [data-ans]").forEach((x) => { if (x.dataset.ans === P.q.answer) x.classList.add("right"); });
    score(ok); feedback(ok, ok ? "Yes, that's an example." : "Not quite.", `<p>The green answer is the example; the others are non-examples. Say in your own words what makes it fit.</p><p class="note">${cite("riccomini", "shanahan")}</p>`);
    return;
  }
  if (P.mode === "say" || P.mode === "tiles") {
    const b = t.closest("[data-ans]"); if (!b) return;
    const ok = b.dataset.ans === P.q.answer || b.textContent === P.q.answer;
    lockOpts(); b.classList.add(ok ? "right" : "wrong");
    $$("#qcard [data-ans]").forEach((x) => { if (x.dataset.ans === P.q.answer) x.classList.add("right"); });
    score(ok);
    if (P.mode === "say") {
      const p = E.parse(P.q.item[0]);
      feedback(ok, ok ? "Yes, that's it." : "Not quite.", `<p>By meaning: ${E.meaningHTML(E.readMeaning(p.ast))}.</p>${speakBtn(P.q.answer, "Read the correct answer aloud")}`);
    } else feedback(ok, ok ? "Yes, that matches the tiles." : "Not quite.", `<p>Count each kind of tile. Red tiles are negative. The tiles show <span class="math">${polyHTML(E.polyOf(E.parse(P.q.decode).ast))}</span>.</p>`);
    return;
  }
  if (P.mode === "same") {
    const b = t.closest("[data-same]"); if (!b) return;
    const pa = E.parse(P.q.a), pb = E.parse(P.q.b);
    const truth = E.equivalent(pa.ast, pb.ast);
    const ok = (b.dataset.same === "1") === truth;
    lockOpts(); b.classList.add(ok ? "right" : "wrong"); score(ok);
    const v = [...new Set([...E.varsIn(pa.ast), ...E.varsIn(pb.ast)])][0] || "x";
    const rows = [-2, -1, 0, 1, 2, 3].map((x) => { const A = E.tryEval(pa.ast, { [v]: new E.Fr(x) }), B = E.tryEval(pb.ast, { [v]: new E.Fr(x) }); const d = A && B && !A.eq(B); return `<tr><td>${x < 0 ? M + Math.abs(x) : x}</td><td class="${d ? "diff" : ""}">${fmtFr(A)}</td><td class="${d ? "diff" : ""}">${fmtFr(B)}</td></tr>`; }).join("");
    feedback(ok, truth ? "They are equivalent." : "They are not equivalent.", `<p>${E.esc(P.q.item[2])}</p>
      <p>Simplified: <span class="math">${polyHTML(E.polyOf(pa.ast))}</span> and <span class="math">${polyHTML(E.polyOf(pb.ast))}</span></p>
      <div class="tablewrap"><table class="tov"><thead><tr><th>${v}</th><th>${E.esc(P.q.a)}</th><th>${E.esc(P.q.b)}</th></tr></thead><tbody>${rows}</tbody></table></div>
      <p class="note">${truth ? "Matching values for a few numbers is a good sign, but simplifying both is what shows they are equal for <b>every</b> value." : "One value that gives different answers is enough to show the expressions are different."} Three strategies you could choose: build both with tiles, test values in a table, or simplify both. ${cite("star", "moschkovich")}</p>`);
    return;
  }
  if (P.mode === "spot") {
    const q = P.q.q;
    if (q.count) {
      const b = t.closest("[data-count]"); if (!b) return;
      const ok = +b.dataset.count === q.count; lockOpts(); b.classList.add(ok ? "right" : "wrong");
      $$("#qcard [data-count]").forEach((x) => { if (+x.dataset.count === q.count) x.classList.add("right"); });
      const ex = $("#spotExpr"); ex.innerHTML = exprHTML(P.q.p, { termSet: termSetOf(P.q.p) }); ex.classList.add("colour"); ex.parentElement.classList.add("boxes"); ex.closest(".qcard").classList.add("boxes");
      score(ok); feedback(ok, ok ? "Correct." : "Not quite.", `<p>${q.explain}</p>`);
      return;
    }
    const tk = t.closest("#spotExpr .tk[data-tok]"); if (!tk) return;
    pickToken(tk);
  }
}
document.addEventListener("keydown", (e) => { if ((e.key === "Enter" || e.key === " ") && e.target.matches && e.target.matches("#spotExpr .tk[data-tok]")) { e.preventDefault(); if (!P.answered) pickToken(e.target); } });
function pickToken(tk) {
  const q = P.q.q, k = +tk.dataset.tok, ok = q.targets.includes(k);
  const ex = $("#spotExpr"); ex.classList.add("colour"); ex.classList.remove("tap");
  $$(".tk[data-tok]", ex).forEach((x) => { if (q.targets.includes(+x.dataset.tok)) x.classList.add("target"); });
  if (!ok) tk.classList.add("picked");
  score(ok); feedback(ok, ok ? "Correct." : "Not quite. The right part is outlined in green.", `<p>${q.explain}</p>`);
}
function checkWrite() {
  if (!$("#writeIn")) return;
  const it = P.q.item, src = $("#writeIn").value.trim();
  const r = tryParse(src);
  const fb = $("#fb");
  if (r.err) { fb.className = "fb show bad"; fb.innerHTML = `<p>${E.esc(r.err)}</p>`; return; }
  const ans = E.parse(it[1]);
  const want = [...E.varsIn(ans.ast)].sort().join(), got = [...E.varsIn(r.p.ast)].sort().join();
  if (want !== got) { fb.className = "fb show bad"; fb.innerHTML = `<p>Use the letter <b class="math">${want}</b> from the question.</p>`; return; }
  const ok = E.equivalent(r.p.ast, ans.ast);
  score(ok);
  $("#writeIn").disabled = true;
  if (ok) {
    const literal = E.plainText(r.p.ast).replace(/\s/g, "") === E.plainText(ans.ast).replace(/\s/g, "");
    feedback(true, "Correct.", `<p>${literal ? "" : `That's equivalent. A word-for-word translation would be <span class="math">${colourExpr(it[1])}</span>.`} Read back: “${E.esc(E.readLiteral(r.p.ast))}”.</p>`);
  } else {
    const trap = it[2].find(([t]) => E.equivalent(E.parse(t).ast, r.p.ast));
    feedback(false, "Not quite.", `<p>${trap ? E.esc(trap[1]) : "Read your expression back and compare it with the words."}</p><p>Yours reads: “${E.esc(E.readLiteral(r.p.ast))}”.</p><p>One answer: <span class="math">${colourExpr(it[1])}</span></p>`);
  }
}
Object.defineProperty(P, "answered", { get() { const fb = $("#fb"); return !!(fb && fb.classList.contains("show") && $("[data-act=next]", fb)); } });

/* ============================================================
   Word bank
   ============================================================ */
const WORDS = [
  { w: "variable", def: "A letter that stands for a number that can change or that we don't know yet.", ex: "3x + 2", role: "var", non: "In “5 kg”, kg is a unit, not a variable.", watch: "A letter is not a short form of a word (c is not “cat”) and not its place in the alphabet (h is not 8)." },
  { w: "coefficient", def: "The number that multiplies the variable in a term.", ex: "5 − 4x²", role: "coef", non: "In x² the 2 is an exponent, not a coefficient.", watch: "The sign in front belongs to the coefficient: in 5 − 4x² it is −4. When no number is written, the coefficient is 1." },
  { w: "constant term", def: "A term with no variable. Its value never changes.", ex: "2x + 7", role: "const", non: "In 2x + 7, the 2 is a coefficient, not a constant term.", everyday: "“Constant” in everyday talk means “all the time”." },
  { w: "exponent", def: "The small raised number. It tells how many times the base is used as a factor.", ex: "x³", role: "exp", non: "3x is not an exponent form: it means 3 times x.", watch: "x² means x · x, not 2x." },
  { w: "power", def: "A base with an exponent, like x³ or 2⁵.", ex: "(2x)³", role: "group", non: "2 × 5 is a product, not a power.", everyday: "In everyday talk, power means strength or electricity." },
  { w: "term", def: "A number, a variable, or numbers and variables multiplied together. Terms are separated by + and − signs outside brackets.", ex: "3x² + 2x − 5", role: "op", non: "2(x + 3) is one term, not two: the bracket keeps it together.", everyday: "A school term is a part of the year." },
  { w: "like terms", def: "Terms with exactly the same variables raised to the same exponents. Only like terms can be combined.", ex: "3x² + x − 2x² + 5x", role: "coef", non: "x² and x are not like terms. Neither are 3x and 3.", everyday: "In everyday talk, “like” means “enjoy” or “similar”." },
  { w: "expression", def: "A mathematical phrase made of numbers, variables and operations. It has no equals sign.", ex: "2(x + 3)", role: "group", non: "2(x + 3) = 10 is an equation, not an expression.", everyday: "A facial expression is a look on someone's face." },
  { w: "product", def: "The result of multiplying. An expression whose last operation is multiplication is a product.", ex: "−3x(4x² − 5)", role: "group", non: "x + 5 is a sum, not a product.", everyday: "In a store, a product is something for sale." },
  { w: "degree", def: "For a term, add the exponents of its variables. For a polynomial, use the highest degree of any term.", ex: "4x²y + 3x", role: "exp", non: "The 4 in 4x²y does not affect the degree.", everyday: "Degrees also measure temperature and angles." },
  { w: "the quantity", def: "What we say aloud for a bracket group, so a listener knows where it starts.", ex: "3(x + 2)", role: "group", non: "“3 times x plus 2” is heard as 3x + 2.", watch: "Without “the quantity”, 3(x + 2) and 3x + 2 sound the same." },
  { w: "opposite", def: "−a is the opposite of a. A number plus its opposite adds to zero.", ex: "−3²", role: "op", non: "In 5 − 3, the − means subtract, not opposite.", watch: "−3² = −9, but (−3)² = 9. The bracket decides what gets squared." },
  { w: "distributive property", def: "Multiply the factor outside the bracket by every term inside the bracket.", ex: "−3x(4x² − 5)", role: "group", non: "−3x(4x² − 5) = −12x³ − 5 skips the last term.", watch: "−3x times −5 is +15x, so the answer is −12x³ + 15x." },
  { w: "substitute / evaluate", def: "Replace each variable with a number in brackets, then work it out in order.", ex: "3x² + 2x − 5", role: "var", non: "Writing 32 for 3x when x = 2 joins digits instead of multiplying.", watch: "Square before multiplying by the coefficient: 3(2)² = 3 × 4." },
  { w: "simplify", def: "Rewrite an expression in a shorter, equivalent way by expanding brackets and combining like terms.", ex: "x(x + 2) + 3(x² + 2x − 5)", role: "coef", non: "Turning 3 + 2x into 5x is not simplifying; it changes the value.", watch: "Simplifying changes how an expression looks, never its value." },
  { w: "equivalent expressions", def: "Expressions that give the same value for every value of the variable.", ex: "2m + 10", role: "coef", non: "2(x − 3) and 2x − 3 agree only at some values, so they are not equivalent.", watch: "A few matching values is a good sign. Simplifying both shows they always match." },
];
const SIGNALS = [
  ["+", "sum, plus, more than, increased by, added to, total", ""],
  [M, "difference, minus, decreased by, less than, subtract … from, fewer than", "“Less than”, “fewer than” and “subtract … from” flip the order: 5 less than x is x − 5."],
  ["×", "product, times, twice (×2), triple (×3), of, groups of", "“Triple” means × 3, not to the power of 3."],
  ["÷", "quotient, divided by, per, half of (÷ 2), shared among", "“The quotient of a and 3” keeps the order: a ÷ 3."],
  ["x²", "squared, cubed, to the power of, the square of", "“The square of the sum of x and 1” is (x + 1)², not x² + 1."],
  ["( )", "the quantity, the sum of … times, all, together", "When words make a whole sum get multiplied, divided or squared, you need brackets."],
];
function buildWords() {
  const grid = $("#wgrid");
  grid.innerHTML = WORDS.map((o) => {
    let exH; try { exH = `<div class="ex colour focus-${o.role}">${exprHTML(E.parse(o.ex))}</div>`; } catch (e) { exH = `<div class="ex">${o.ex}</div>`; }
    return `<article class="word" data-w="${E.esc((o.w + " " + o.def).toLowerCase())}"><h3>${o.w}</h3><p>${o.def}</p>${exH}
      <p class="nonex"><b>Not an example:</b> ${E.esc(o.non)}</p>
      ${o.everyday ? `<p class="everyday"><b>Everyday meaning:</b> ${E.esc(o.everyday)} The math meaning is more precise.</p>` : ""}
      ${o.watch ? `<p class="watch"><b>Watch out:</b> ${E.esc(o.watch)}</p>` : ""}
      <p class="own">In your own words: what does <b>${o.w}</b> mean?</p></article>`;
  }).join("");
  $("#signals tbody").innerHTML = SIGNALS.map(([s, w, n]) => `<tr><td>${s}</td><td>${w}${n ? `<br><span class="flip">${n}</span>` : ""}</td></tr>`).join("");
  $("#wsearch").addEventListener("input", (e) => { const q = e.target.value.toLowerCase().trim(); $$("#wgrid .word").forEach((a) => (a.style.display = !q || a.dataset.w.includes(q) ? "" : "none")); });
  buildLanguageExtras();
  $("#wordsWhy").innerHTML = why("Math words need explicit teaching and many exposures. Words like product, term and degree mean something more precise in math than in everyday talk, so the two meanings are set side by side.", "riccomini", "shanahan");
}
function buildResearch() {
  const groups = [...new Set(Object.values(REFS).map((r) => r.group))];
  $("#refs").innerHTML = groups.map((g) => `<section class="block"><h3>${g}</h3><div class="refgrid">${Object.entries(REFS).filter(([, r]) => r.group === g).map(([id, r]) => `<article class="ref" id="ref-${id}">
    <h4>${r.short}</h4><p class="apa">${r.apa}${r.link ? ` <a href="${r.link}" target="_blank" rel="noopener">Link</a>` : ""}</p>
    <p><b>What it found:</b> ${r.found}</p><p class="forteach"><b>For your teaching:</b> ${REF_TEACH[id]}</p><p><b>In this app:</b> ${r.app}</p><p class="note">Reviewed from: ${r.access}</p></article>`).join("")}</div></section>`).join("");
}

/* ============================================================
   Routing, text size, start-up
   ============================================================ */
const VIEWS = { start: "view-start", model: "view-decode", routine: "view-learn", respond: "view-respond", practice: "view-practice", student: "view-practice", language: "view-words", research: "view-research" };
const ALIAS = { decode: "model", "six-s": "routine", "word-bank": "language" };
function go(name, push = true) {
  name = ALIAS[name] || name;
  if (!VIEWS[name]) name = "start";
  $$(".view").forEach((v) => v.classList.toggle("on", v.id === VIEWS[name]));
  document.body.classList.toggle("student-mode", name === "student");
  document.title = name === "student" ? "Algebra Practice" : "Algebra Decoder";
  $$(".tabs a").forEach((a) => a.setAttribute("aria-current", a.getAttribute("href") === "#" + name ? "page" : "false"));
  if (push && location.hash !== "#" + name) { try { history.replaceState(null, "", "#" + name); } catch (e) { location.hash = name; } }
  snapshot();
}
function snapshot() { /* state for live republish */ }
function start(saved) {
  buildStart(); buildDecode(); buildLearn(); buildRespond(); buildPractice(); buildWords(); buildResearch();
  $$("[data-c]").forEach((el) => (el.outerHTML = cite(el.dataset.c)));
  $("#rlmCite").outerHTML = cite("shanahan");
  $("#exprIn").value = (saved && saved.expr) || "3x² + x − 2x² + 5x";
  decode(true);
  window.addEventListener("hashchange", () => go(location.hash.slice(1), false));
  go((location.hash || "#start").slice(1), false);
  $("#backTeacher").addEventListener("click", () => { go("practice"); window.scrollTo({ top: 0 }); });
  $("#bigText").addEventListener("click", (e) => { const on = document.documentElement.classList.toggle("big"); e.currentTarget.setAttribute("aria-pressed", on); try { localStorage.setItem("ad-big", on ? "1" : ""); } catch (err) { /* storage off */ } });
  try { if (localStorage.getItem("ad-big")) { document.documentElement.classList.add("big"); $("#bigText").setAttribute("aria-pressed", "true"); } } catch (err) { /* storage off */ }
  try { window.claude?.hot?.snapshot?.(() => ({ expr: $("#exprIn").value })); } catch (err) { /* outside viewer */ }
}
window.claude?.hot?.ready ? window.claude.hot.ready(start) : start(window.claude?.hot?.data ?? {});
